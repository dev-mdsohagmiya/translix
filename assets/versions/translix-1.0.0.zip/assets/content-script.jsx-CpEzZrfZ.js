import{A as X,r as I,i as yt,j as c,c as lt}from"./providerService-C-RXBSxf.js";function wt(t,n){let e;return function(...r){const a=()=>{clearTimeout(e),t(...r)};clearTimeout(e),e=setTimeout(a,n)}}function ct(t){if(!t)return!1;if(t.tagName==="TEXTAREA"||t.tagName==="INPUT"&&/^(text|search|url|tel|email|password)$/i.test(t.type))return!0;if(t.tagName==="DIV"||t.tagName==="SPAN"){if(t.contentEditable==="true"||t.isContentEditable)return!0;const n=t.getAttribute("role");if(n==="textbox"||n==="combobox")return!0;const o=(t.className||"").toLowerCase();if(o.includes("input")||o.includes("textbox")||o.includes("editor")||o.includes("composer")||o.includes("textarea")||o.includes("post")||o.includes("comment")||o.includes("message")||t.getAttribute("data-testid")&&t.getAttribute("data-testid").toLowerCase().includes("input")||t.oninput||t.onkeydown||t.onkeyup||t.onpaste)return!0}return!1}function vt(){const t=document.activeElement;if(ct(t)){if(t.tagName==="INPUT"||t.tagName==="TEXTAREA"){const r=t.selectionStart,a=t.selectionEnd;if(r===a)return null;const s=window.getComputedStyle(t),i=document.createElement("div");i.style.position="absolute",i.style.visibility="hidden",i.style.height="auto",i.style.width="auto",i.style.whiteSpace=t.tagName==="TEXTAREA"?"pre-wrap":"nowrap",["fontFamily","fontSize","fontWeight","letterSpacing","lineHeight","padding"].forEach(u=>{i.style[u]=s[u]}),document.body.appendChild(i);const l=t.value.substring(0,r);i.textContent=l;const p=t.getBoundingClientRect(),m=i.getBoundingClientRect();return document.body.removeChild(i),{left:p.left+(l.length>0?Math.min(m.width,p.width-20):0),top:p.top,right:p.left+Math.min(m.width+50,p.width),bottom:p.bottom,width:Math.min(50,p.width-(m.width||0)),height:p.height}}if(t.tagName==="DIV"||t.tagName==="SPAN"){const r=window.getSelection();if(!r||r.isCollapsed)return null;const s=r.getRangeAt(0).getBoundingClientRect();if(s.width>0&&s.height>0)return{left:s.left,top:s.top,right:s.right,bottom:s.bottom,width:s.width,height:s.height};const i=t.getBoundingClientRect();return{left:i.left,top:i.top,right:i.right,bottom:i.bottom,width:i.width,height:i.height}}}const n=window.getSelection();if(!n.rangeCount)return null;const e=n.getRangeAt(0),o=e.getBoundingClientRect();if(o.width===0&&o.height===0){const r=e.commonAncestorContainer;return(r.nodeType===1?r:r.parentElement).getBoundingClientRect()}return o}function pt(){const t=document.activeElement;if(ct(t)){if(t.tagName==="INPUT"||t.tagName==="TEXTAREA"){const i=t.selectionStart,l=t.selectionEnd;if(i!==l){const p=t.value.substring(i,l);return console.log("Input selection:",p),t.closest("#translation-box-container")?(console.log("Selection detected in translation box input"),{text:p,type:"translationBoxInput",element:t,start:i,end:l,originalValue:t.value}):{text:p,type:"input",element:t,start:i,end:l,originalValue:t.value}}return null}if(t.tagName==="DIV"||t.tagName==="SPAN"){const i=window.getSelection();if(!i||i.isCollapsed)return null;const l=i.toString();return l?(console.log("Input-like div selection:",l),t.closest("#translation-box-container")?(console.log("Selection detected in translation box input-like div"),{text:l,type:"translationBoxInput",element:t,start:0,end:l.length,originalValue:t.textContent||t.innerText}):{text:l,type:"inputLikeDiv",element:t,selection:i,range:i.getRangeAt(0).cloneRange(),originalValue:t.textContent||t.innerText}):null}}const n=window.getSelection();if(!n||n.isCollapsed)return null;const e=n.toString();if(!e)return null;const o=n.getRangeAt(0),r=o.commonAncestorContainer;let s=r.nodeType===1?r:r.parentElement;for(;s&&!Et(s);)s=s.parentElement;return s?(console.log("ContentEditable selection:",e),{text:e,type:"contenteditable",selection:n,range:o.cloneRange(),editableElement:s,originalHTML:s.innerHTML}):(console.log("Regular selection:",e),{text:e,type:"regular",selection:n,range:o.cloneRange()})}function Et(t){return t&&(t.contentEditable==="true"||t.isContentEditable||t.getAttribute&&t.getAttribute("contenteditable")==="true")}function U(){const t=vt();if(!t)return null;const n=window.scrollX||document.documentElement.scrollLeft,e=window.scrollY||document.documentElement.scrollTop,o=window.innerWidth-t.right;t.left;const r=window.innerHeight-t.bottom,a=t.top;let s,i;r>=35?(s=t.bottom+e+5,i=t.left+n+t.width/2-12):o>=35?(s=t.top+e+t.height/2-12,i=t.right+n+5):a>=35?(s=t.top+e-30,i=t.left+n+t.width/2-12):(s=t.top+e+t.height/2-12,i=t.left+n-30);const l=24,p=24,u=l+34+l,g=window.innerWidth+n-u-10,f=window.innerHeight+e-p-10,x=n+10,E=e+10;return i=Math.max(x,Math.min(i,g)),s=Math.max(E,Math.min(s,f)),(i<x||i>g||s<E||s>f)&&(console.log("Icon position was outside viewport, repositioning to safe area"),s=Math.floor((window.innerHeight-p)/2)+e,i=Math.floor((window.innerWidth-u)/2)+n,i=Math.max(x,Math.min(i,g)),s=Math.max(E,Math.min(s,f))),{top:s,left:i}}function dt(){const t=document.body,n=document.documentElement,e={hasFixedHeader:!1,hasSidebar:!1,hasOverflowHidden:!1,bodyOverflow:"visible",htmlOverflow:"visible",isFiverr:!1,isProblematicWebsite:!1,hasAggressiveCSS:!1,hasFixedElements:[],viewportInfo:{width:window.innerWidth,height:window.innerHeight,scrollX:window.scrollX||document.documentElement.scrollLeft,scrollY:window.scrollY||document.documentElement.scrollTop}},o=window.location.hostname.toLowerCase();o.includes("fiverr.com")&&(e.isFiverr=!0,e.isProblematicWebsite=!0,e.hasAggressiveCSS=!0),(o.includes("upwork.com")||o.includes("freelancer.com")||o.includes("guru.com")||o.includes("peopleperhour.com")||o.includes("linkedin.com")||o.includes("facebook.com")||o.includes("twitter.com")||o.includes("instagram.com")||o.includes("youtube.com")||o.includes("github.com")||o.includes("stackoverflow.com"))&&(e.isProblematicWebsite=!0,e.hasAggressiveCSS=!0),["header",".header",".navbar",".nav",".navigation",".top-bar",".topbar",'[class*="header"]','[class*="navbar"]','[class*="nav"]','[class*="menu"]','[class*="toolbar"]','[class*="bar"]','[class*="fixed"]','[class*="sticky"]'].forEach(u=>{try{document.querySelectorAll(u).forEach(f=>{const x=window.getComputedStyle(f);(x.position==="fixed"||x.position==="sticky")&&(e.hasFixedHeader=!0,e.hasFixedElements.push({element:f,position:x.position,top:x.top,height:f.offsetHeight,zIndex:parseInt(x.zIndex)||0}))})}catch{}}),[".sidebar",".aside",".panel",".drawer",".drawer-side",'[class*="sidebar"]','[class*="aside"]','[class*="panel"]','[class*="drawer"]','[class*="menu"]','[class*="nav"]'].forEach(u=>{try{document.querySelectorAll(u).forEach(f=>{const x=window.getComputedStyle(f),E=f.getBoundingClientRect();E.width<300&&E.height>window.innerHeight*.5&&(e.hasSidebar=!0,e.hasFixedElements.push({element:f,position:x.position,left:x.left,width:E.width,zIndex:parseInt(x.zIndex)||0}))})}catch{}});const s=window.getComputedStyle(t),i=window.getComputedStyle(n);e.bodyOverflow=s.overflow,e.htmlOverflow=i.overflow,e.hasOverflowHidden=s.overflow==="hidden"||i.overflow==="hidden";const l=document.querySelectorAll("*");let p=0,m=0;return l.forEach(u=>{const g=window.getComputedStyle(u);g.zIndex&&parseInt(g.zIndex)>1e3&&(p++,m++),(g.position==="fixed"||g.position==="absolute")&&p++}),(p>50||m>10)&&(e.hasAggressiveCSS=!0),e.hasFixedElements.sort((u,g)=>g.zIndex-u.zIndex),e}function K(){const t=window.innerWidth,n=window.innerHeight,e=400,o=Math.min(600,Math.max(400,Math.floor(n*.8)));dt();let r={width:e,height:o,top:20,left:"auto",right:20,zIndex:2147483647};return o>n-40&&(r.height=n-40,r.top=20),e>t-40&&(r.width=t-40,r.right=20,r.left="auto"),console.log(`Calculated viewport-relative top-right box position: top=${r.top}, left=${r.left}, right=${r.right}, width=${r.width}, height=${r.height}, viewport=${t}x${n}`),r}function kt(t){console.log("Showing loading indicator"),document.querySelectorAll("[data-translate-icon]").forEach(o=>{o.parentNode&&o.parentNode.removeChild(o)});const e=document.createElement("div");e.id="loading-indicator",e.style.position="absolute",e.style.top=`${t.top}px`,e.style.left=`${t.left}px`,e.style.width="50px",e.style.height="32px",e.style.background="rgba(255, 255, 255, 0.95)",e.style.border="1px solid rgba(0, 0, 0, 0.1)",e.style.borderRadius="16px",e.style.boxShadow="0 4px 20px rgba(0, 0, 0, 0.15)",e.style.zIndex="2147483647",e.style.display="flex",e.style.alignItems="center",e.style.justifyContent="center",e.style.backdropFilter="blur(10px)",e.style.gap="4px";for(let o=0;o<3;o++){const r=document.createElement("div");r.style.width="6px",r.style.height="6px",r.style.borderRadius="50%",r.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",r.style.animation=`tranai-dot-bounce 1.4s ease-in-out ${o*.2}s infinite`,e.appendChild(r)}if(!document.getElementById("tranai-loading-styles")){const o=document.createElement("style");o.id="tranai-loading-styles",o.textContent=`
      @keyframes tranai-dot-bounce {
        0%, 80%, 100% {
          transform: translateY(0px);
          opacity: 0.5;
        }
        40% {
          transform: translateY(-8px);
          opacity: 1;
        }
      }
    `,document.head.appendChild(o)}return document.body.appendChild(e),e}function k(){const t=document.getElementById("loading-indicator");t&&t.parentNode?(console.log("Removing loading indicator"),t.parentNode.removeChild(t)):console.log("Loading indicator not found or already removed");const n=document.getElementById("tranai-loading-styles");n&&n.parentNode&&n.parentNode.removeChild(n)}function mt(){return new Promise(t=>{try{const n=localStorage.getItem("translix_settings");if(n){const e=JSON.parse(n);console.log("Loaded settings from localStorage:",e),t(e);return}typeof chrome<"u"&&chrome.storage?chrome.storage.local.get(["translix_settings"],e=>{const o=e.translix_settings;console.log("Loaded settings from chrome.storage:",o),t(o||null)}):(console.log("No storage available"),t(null))}catch(n){console.error("Failed to load settings:",n),t(null)}})}function Ct(){try{return!!chrome.runtime.id}catch(t){return console.error("Extension context invalidated:",t),!1}}async function*gt(t,n=null,e=!1){if(!Ct())throw new Error("Extension context invalidated");console.log(`Starting stream for message: ${t}, language: ${n}, stream: ${e}`);try{let o=n;if(!o&&t.includes("=")){const i=t.match(/^(\w+)=true:/);i&&(o=i[1])}const r=await mt();console.log("Loaded settings:",r);const a={...X.requestBody,userMessage:t,language:o||"EN",stream:e};r?(r.provider&&(a.provider=r.provider,console.log("✅ Added provider:",r.provider)),r.apiKey&&(a.apiKey=r.apiKey,console.log("✅ Added API key:",r.apiKey?"***"+r.apiKey.slice(-4):"none")),r.model&&(a.model=r.model,console.log("✅ Added model:",r.model))):console.log("⚠️ No provider settings found in storage"),console.log("📤 Final stream request body:",a),console.log("🌐 Making API request to:",X.baseURL);const s=await fetch(X.baseURL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(a)});if(console.log("📥 API response status:",s.status,s.statusText),!s.ok)throw new Error(`HTTP error! status: ${s.status}`);if(e){const i=s.body.getReader(),l=new TextDecoder;let p="";for(;;){const{done:m,value:u}=await i.read();if(m)break;const g=l.decode(u);p+=g,console.log("Received raw stream chunk:",g);const f=p.split(`
`);p=f.pop()||"";for(const x of f)if(x.trim())try{const E=JSON.parse(x.trim());if(console.log("Parsed JSON chunk:",E),E.done){console.log("Stream completed with done flag");return}E.message&&(console.log("Yielding message:",E.message),yield E.message)}catch(E){console.warn("Failed to parse JSON chunk:",x,E),x.trim()&&(yield x.trim())}}if(p.trim())try{const m=JSON.parse(p.trim());m.message&&!m.done&&(yield m.message)}catch(m){console.warn("Failed to parse final buffer:",p,m),p.trim()&&(yield p.trim())}}else{const i=await s.json();console.log("Non-streaming response:",i),yield i.response||i.message||i.text||JSON.stringify(i)}console.log("Stream completed")}catch(o){throw console.error(`Stream error: ${o.message}`),new Error(`Stream error: ${o.message}`)}}async function St(){console.log("🔍 Debugging settings loading...");const t=localStorage.getItem("translix_settings");console.log("localStorage settings:",t?JSON.parse(t):"null"),typeof chrome<"u"&&chrome.storage&&chrome.storage.local.get(["translix_settings"],e=>{console.log("chrome.storage settings:",e.translix_settings||"null")});const n=await mt();console.log("loadSettings() result:",n)}const ut=({selectedText:t,targetLang:n,onClose:e})=>{const[o,r]=I.useState([]),[a,s]=I.useState(!1),[i,l]=I.useState(""),[p,m]=I.useState(""),[u,g]=I.useState(!1);I.useEffect(()=>{const h=b=>{const{text:y,targetLang:C}=b.detail;y&&C===n&&(console.log("Appending new translation to messages:",y),r(N=>[...N,y]))},v=b=>{const{newValue:y,start:C,end:N,newText:z}=b.detail;console.log("Translation box input change:",{newValue:y,start:C,end:N,newText:z}),console.log("Current inputValue before update:",p),m(y),console.log("Input value updated to:",y)},w=document.getElementById("translation-box-container");return w&&(w.addEventListener("appendTranslation",h),w.addEventListener("translationBoxInputChange",v)),t&&n&&(r([t]),f(t,n)),()=>{w&&(w.removeEventListener("appendTranslation",h),w.removeEventListener("translationBoxInputChange",v))}},[t,n]),I.useEffect(()=>{const h=document.querySelector("#translation-box-container .chat-input");if(h&&h.value!==p&&(console.log("Syncing DOM with React state:",p),h.value=p,window.lastTranslationSelection)){const{start:v,newText:w}=window.lastTranslationSelection,b=v+w.length;h.setSelectionRange(b,b),window.lastTranslationSelection=null}},[p]);const f=async(h,v)=>{if(console.log("fetchTranslation called with:",{text:h,lang:v}),!yt()){const y="First configure your provider in settings to start translating.";console.log("Provider not configured, showing error message:",y),r(C=>[...C,y]);return}s(!0),l("");const w=3;let b=0;for(;b<w;)try{const y=`${v}=true: ${h}`;console.log(`Starting streaming translation for: ${y} (attempt ${b+1})`);const C=gt(y,v,!0);let N="";for await(const z of C)console.log("Received streaming chunk:",z),N+=z,l(N);console.log("Streaming translation completed:",N),r(z=>[...z,N]),l("");break}catch(y){if(b++,console.error(`Translation attempt ${b} failed:`,y),b>=w){const C=`Error: ${y.message}. Please check your API configuration.`;console.log("All retries failed, adding error message:",C),r(N=>[...N,C]),l("")}else console.log(`Waiting ${1e3*b}ms before retry ${b+1}`),await new Promise(C=>setTimeout(C,1e3*b)),l(`Retrying... (${b}/${w})`)}console.log("fetchTranslation completed"),s(!1)},x=async h=>{if(console.log("handleQuickTranslate called with lang:",h),console.log("Current input value:",p),p.trim()){const v=p.trim();console.log("Adding user message to chat:",v),r(w=>[...w,v]),m(""),console.log("Starting translation for:",v,"to",h),await f(v,h)}else console.log("No input value to translate")},E=async h=>{try{await navigator.clipboard.writeText(h),console.log("Text copied to clipboard"),g(!0),setTimeout(()=>g(!1),2e3)}catch(v){console.error("Failed to copy text:",v)}},bt={width:"400px",height:"600px"};return c.jsxs("div",{className:"translation-box-main",style:bt,children:[c.jsx("div",{className:"translation-box-header",children:c.jsxs("div",{className:"header-content",children:[c.jsxs("div",{className:"header-left",children:[c.jsx("div",{className:"logo-container",children:c.jsx("img",{src:"https://i.postimg.cc/QVLmn52N/logo.png",alt:"Translix Logo",className:"logo-icon",onError:h=>{h.target.outerHTML=`
                    <svg class="logo-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"></path>
                    </svg>
                  `}})}),c.jsxs("div",{className:"header-text",children:[c.jsx("h3",{className:"app-title",children:"Translix"}),c.jsx("p",{className:"app-subtitle",children:"Smart Translation"})]})]}),c.jsx("button",{onClick:e,disabled:a,className:"close-button",title:"Close",children:c.jsx("svg",{className:"close-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]})}),c.jsxs("div",{className:"messages-container",children:[o.length===0&&!a&&c.jsx("div",{className:"loading-container",children:c.jsxs("div",{className:"loading-content",children:[c.jsx("div",{className:"loading-spinner"}),c.jsx("p",{className:"loading-text",children:"Loading Translix..."})]})}),o.map((h,v)=>{const w=v%2===0,b=h.startsWith("Error:");let y="message-bubble";return b?y+=" error-message":w?y+=" user-message":y+=" ai-message",c.jsx("div",{className:w?"message-wrapper user-wrapper":"message-wrapper ai-wrapper",children:c.jsxs("div",{className:y,children:[c.jsxs("div",{className:"message-content",children:[c.jsx("div",{className:`message-icon ${b?"error-icon":w?"user-icon":"ai-icon"}`,children:b?c.jsx("svg",{className:"icon-svg",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"})}):w?c.jsx("svg",{className:"icon-svg",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"})}):c.jsx("svg",{className:"icon-svg",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"})})}),c.jsxs("div",{className:"message-text-container",children:[c.jsx("p",{className:`message-text ${b?"error-text":""}`,children:h}),b&&c.jsxs("div",{className:"troubleshooting-section",children:[c.jsx("p",{className:"troubleshooting-title",children:"💡 Troubleshooting:"}),c.jsxs("ul",{className:"troubleshooting-list",children:[c.jsx("li",{children:"Check if your API server is running"}),c.jsx("li",{children:"Verify your API key and provider settings"}),c.jsx("li",{children:"Try refreshing the page and try again"})]})]})]})]}),c.jsx("button",{className:`copy-button ${w?"user-copy":"ai-copy"}`,onClick:()=>E(h),title:"Copy message",children:c.jsx("svg",{className:"copy-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"})})})]})},v)}),a&&c.jsx("div",{className:"message-wrapper ai-wrapper",children:c.jsx("div",{className:"loading-message-bubble",children:c.jsxs("div",{className:"loading-message-content",children:[i?c.jsx("div",{className:"streaming-content",children:c.jsxs("p",{className:"streaming-text",children:[i,c.jsx("span",{className:"streaming-cursor",children:"|"})]})}):c.jsxs("div",{className:"loading-dots",children:[c.jsx("div",{className:"loading-dot dot-1"}),c.jsx("div",{className:"loading-dot dot-2"}),c.jsx("div",{className:"loading-dot dot-3"})]}),c.jsx("span",{className:"loading-status",children:i?"Translating...":"Starting translation..."})]})})})]}),u&&c.jsx("div",{className:"copy-alert",children:c.jsxs("div",{className:"copy-alert-content",children:[c.jsx("div",{className:"copy-alert-icon",children:c.jsx("svg",{className:"check-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M5 13l4 4L19 7"})})}),c.jsx("span",{className:"copy-alert-text",children:"Copied to clipboard!"})]})}),c.jsx("div",{className:"input-form",children:c.jsxs("div",{className:"input-container",children:[c.jsx("input",{type:"text",value:p,onChange:h=>m(h.target.value),className:"chat-input",placeholder:"Type a message to translate...",disabled:a}),c.jsxs("div",{className:"button-container",children:[c.jsxs("button",{type:"button",onClick:()=>x("BN"),disabled:a||!p.trim(),className:"translate-button bn-button",children:[c.jsx("svg",{className:"button-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"})}),"Translate to BN"]}),c.jsxs("button",{type:"button",onClick:()=>x("EN"),disabled:a||!p.trim(),className:"translate-button en-button",children:[c.jsx("svg",{className:"button-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"})}),"Translate to EN"]})]})]})})]})};function $(){try{return!!chrome.runtime.id}catch(t){return console.error("Extension context invalidated:",t),!1}}let R=null,P=!1,S=!1;const rt=500;function Nt(t,n,e){if(!$()){console.warn("Cannot create translate icons: extension context invalidated");return}T(),k(),console.log("Creating translate icons");const o=U();if(!o){console.log("No valid position for icons");return}const r=window.PRIMARY_LANG||"BN",a=document.createElement("div");a.innerText=r,a.setAttribute("data-translate-icon","primary"),a.style.position="absolute",a.style.top=`${o.top}px`,a.style.left=`${o.left}px`,a.style.width="32px",a.style.height="32px",a.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",a.style.border="2px solid rgba(255, 255, 255, 0.3)",a.style.borderRadius="50%",a.style.boxShadow="0 4px 20px rgba(102, 126, 234, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",a.style.cursor="pointer",a.style.zIndex=2147483647,a.style.display="flex",a.style.alignItems="center",a.style.justifyContent="center",a.style.fontSize="11px",a.style.fontWeight="700",a.style.color="#ffffff",a.style.fontFamily="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",a.style.textShadow="0 1px 2px rgba(0, 0, 0, 0.3)",a.style.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",a.style.backdropFilter="blur(10px)",a.style.userSelect="none";const s=document.createElement("div");s.innerText="EN",s.setAttribute("data-translate-icon","en"),s.style.position="absolute",s.style.top=`${o.top}px`,s.style.left=`${o.left+40}px`,s.style.width="32px",s.style.height="32px",s.style.background="linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",s.style.border="2px solid rgba(255, 255, 255, 0.3)",s.style.borderRadius="50%",s.style.boxShadow="0 4px 20px rgba(240, 147, 251, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",s.style.cursor="pointer",s.style.zIndex=2147483647,s.style.display="flex",s.style.alignItems="center",s.style.justifyContent="center",s.style.fontSize="11px",s.style.fontWeight="700",s.style.color="#ffffff",s.style.fontFamily="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",s.style.textShadow="0 1px 2px rgba(0, 0, 0, 0.3)",s.style.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",s.style.backdropFilter="blur(10px)",s.style.userSelect="none",a.addEventListener("mouseenter",()=>{a.style.transform="scale(1.15) translateY(-2px)",a.style.boxShadow="0 8px 30px rgba(102, 126, 234, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)",a.style.background="linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%)"}),a.addEventListener("mouseleave",()=>{a.style.transform="scale(1) translateY(0px)",a.style.boxShadow="0 4px 20px rgba(102, 126, 234, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",a.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",clearTimeout(R),console.log("Mouse left primary icon, cleared timer")}),s.addEventListener("mouseenter",()=>{s.style.transform="scale(1.15) translateY(-2px)",s.style.boxShadow="0 8px 30px rgba(240, 147, 251, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)",s.style.background="linear-gradient(135deg, #ec4899 0%, #f43f5e 100%)"}),s.addEventListener("mouseleave",()=>{s.style.transform="scale(1) translateY(0px)",s.style.boxShadow="0 4px 20px rgba(240, 147, 251, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",s.style.background="linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",clearTimeout(R),console.log("Mouse left EN icon, cleared timer")}),a.addEventListener("mousedown",()=>{a.style.transform="scale(1.05) translateY(0px)",a.style.boxShadow="0 2px 10px rgba(102, 126, 234, 0.5), 0 1px 4px rgba(0, 0, 0, 0.2)"}),a.addEventListener("mouseup",()=>{a.style.transform="scale(1.15) translateY(-2px)",a.style.boxShadow="0 8px 30px rgba(102, 126, 234, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)"}),s.addEventListener("mousedown",()=>{s.style.transform="scale(1.05) translateY(0px)",s.style.boxShadow="0 2px 10px rgba(240, 147, 251, 0.5), 0 1px 4px rgba(0, 0, 0, 0.2)"}),s.addEventListener("mouseup",()=>{s.style.transform="scale(1.15) translateY(-2px)",s.style.boxShadow="0 8px 30px rgba(240, 147, 251, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)"}),a.addEventListener("pointerdown",i=>{i.preventDefault(),i.stopPropagation(),S=!0,P=!1,console.log("Pointer down on primary icon, starting long press timer"),R=setTimeout(()=>{if(P=!0,console.log("Long press detected on primary icon"),console.log("Current selection info:",e),!e||!e.text){console.log("No valid selection info, aborting long press"),S=!1;return}console.log("Creating translation box for:",e.text,"in language:",r),n(e.text,r),T(),console.log("Icons removed after long press"),S=!1},rt)}),s.addEventListener("pointerdown",i=>{i.preventDefault(),i.stopPropagation(),S=!0,P=!1,console.log("Pointer down on EN icon, starting long press timer"),R=setTimeout(()=>{if(P=!0,console.log("Long press detected on EN icon"),console.log("Current selection info:",e),!e||!e.text){console.log("No valid selection info, aborting long press"),S=!1;return}console.log("Creating translation box for:",e.text,"in language: EN"),n(e.text,"EN"),T(),console.log("Icons removed after long press"),S=!1},rt)}),a.addEventListener("pointerup",async i=>{i.preventDefault(),i.stopPropagation(),clearTimeout(R),P?console.log("Pointer up after long press on primary icon, keeping box open"):(console.log("Regular click on primary icon"),e&&e.text?await t(r,e):console.log("No valid selection info for primary icon click")),S=!1}),s.addEventListener("pointerup",async i=>{i.preventDefault(),i.stopPropagation(),clearTimeout(R),P?console.log("Pointer up after long press on EN icon, keeping box open"):(console.log("Regular click on EN icon"),e&&e.text?await t("EN",e):console.log("No valid selection info for EN icon click")),S=!1}),a.addEventListener("contextmenu",i=>i.preventDefault()),s.addEventListener("contextmenu",i=>i.preventDefault()),document.body.appendChild(a),document.body.appendChild(s)}function T(){console.log("removeTranslateIcon called"),document.querySelectorAll("[data-translate-icon]").forEach(n=>{n.parentNode&&(console.log(`Removing ${n.getAttribute("data-translate-icon")} icon`),n.parentNode.removeChild(n))})}function V(){const t=document.querySelector('[data-translate-icon="primary"]'),n=document.querySelector('[data-translate-icon="en"]');return{iconElementBN:t,iconElementEN:n}}function ft(){return console.log("Checking long press state:",S),S}function et(){console.log("Resetting long press state"),S=!1,P=!1,R&&(clearTimeout(R),R=null)}let Y="",O=null;function Rt(t,n,e){if(ft()){console.log("Skipping selection event during long press processing");return}if(!$()){console.warn("Cannot handle selection event: extension context invalidated");return}const o=pt(),r=q();if(o&&o.text&&r){const i=window.getSelection().getRangeAt(0).commonAncestorContainer;if(r.contains(i.nodeType===1?i:i.parentElement)){console.log("Selection inside translation box, ignoring"),n();return}}if(o&&o.text){const a=Y;Y=o.text,O=o,console.log("Selection detected:",o.text,"Previous text was:",a,"Current state - lastSelectedText:",Y,"currentSelectionInfo:",!!O),t()}else(!o||!o.text)&&(console.log("No valid selection, removing icons and clearing state"),Y="",O=null,n(),e())}function A(){return O}function Tt(){console.log("Initializing selection state"),Y="",O=null,et()}let d=null,L=null,F=null,_=null,W=null,B=null;function at(t,n,e){console.log("Recreating box with forced top-right positioning"),t&&t.parentNode&&t.parentNode.removeChild(t);const o=document.createElement("div");o.id="translation-box-container";const r={position:"fixed",top:"20px",right:"20px",left:"auto",width:"400px",height:"600px",zIndex:"2147483647",boxSizing:"border-box",pointerEvents:"auto",visibility:"visible",opacity:"1",transform:"none",filter:"none",backdropFilter:"none",margin:"0",padding:"0",border:"none",outline:"none"};Object.assign(o.style,r),o.style.setProperty("position","fixed","important"),o.style.setProperty("top","20px","important"),o.style.setProperty("right","20px","important"),o.style.setProperty("left","auto","important"),o.style.setProperty("z-index","2147483647","important"),document.body.appendChild(o),d=o,L=lt.createRoot(o),L.render(c.jsx(ut,{selectedText:n,targetLang:e,onClose:()=>{console.log("Close button clicked"),M()}})),console.log("Box recreated with forced top-right positioning")}function J(t){if(!t)return;t.parentNode&&t.parentNode!==document.body&&document.body.appendChild(t);const n={position:"fixed",zIndex:"2147483647",elevation:"2147483647",layer:"2147483647",isolation:"isolate",contain:"layout style paint",willChange:"transform",transform:"translateZ(0)",overflow:"visible",clip:"auto",clipPath:"none"};Object.assign(t.style,n),t.style.setProperty("z-index","2147483647","important"),t.style.setProperty("position","fixed","important"),t.style.setProperty("isolation","isolate","important"),t.style.setProperty("contain","layout style paint","important"),t.style.setProperty("will-change","transform","important"),t.style.setProperty("transform","translateZ(0)","important"),console.log("Forced maximum z-index applied"),setTimeout(()=>{const e=window.getComputedStyle(t);console.log("Computed z-index:",e.zIndex),console.log("Computed position:",e.position)},10)}function j(t){if(!t)return;const n=window.innerWidth,e=window.innerHeight,o=20,r={position:"fixed",top:`${o}px`,right:`${o}px`,left:"auto",width:"400px",height:"600px",zIndex:"2147483647",visibility:"visible",opacity:"1",pointerEvents:"auto",transform:"none",boxSizing:"border-box"};Object.assign(t.style,r),console.log("Forced viewport-relative top-right positioning applied"),setTimeout(()=>{const a=t.getBoundingClientRect();console.log("Position after force top-right:",{rect:{top:a.top,left:a.left,right:a.right,bottom:a.bottom},expected:{top:o,right:n-o},viewport:{width:n,height:e}})},10)}function H(t){if(!t)return;const n=t.getBoundingClientRect(),e=window.innerWidth,o=window.innerHeight;window.scrollX||document.documentElement.scrollLeft,window.scrollY||document.documentElement.scrollTop;let r=!1,a={};(n.width<=0||n.height<=0)&&(console.log("Box has invalid dimensions, repositioning"),r=!0,a={width:"400px",height:"600px"}),(n.left<0||n.left>e)&&(a.right="20px",a.left="auto",r=!0),(n.right>e||n.right<0)&&(a.right="20px",a.left="auto",r=!0),(n.top<0||n.top>o)&&(a.top="20px",r=!0),(n.bottom>o||n.bottom<0)&&(a.top="20px",r=!0),n.width<200&&(a.width="400px",r=!0),n.height<300&&(a.height="600px",r=!0);const s={visibility:"visible",opacity:"1",display:"block",zIndex:"2147483647",position:"fixed",pointerEvents:"auto",transform:"none",filter:"none",backdropFilter:"none"};Object.assign(t.style,s);let i=t.parentElement,l=0;const p=10;for(;i&&i!==document.body&&l<p;){const g=window.getComputedStyle(i);g.overflow==="hidden"&&(i.style.overflow="visible"),g.visibility==="hidden"&&(i.style.visibility="visible"),g.display==="none"&&(i.style.display="block"),g.opacity==="0"&&(i.style.opacity="1"),g.transform&&g.transform!=="none"&&(i.style.transform="none"),g.filter&&g.filter!=="none"&&(i.style.filter="none"),i=i.parentElement,l++}if(r){console.log("Box needs repositioning:",a),Object.assign(t.style,a),t.offsetHeight;const g=t.getBoundingClientRect();if(g.left<0||g.right>e||g.top<0||g.bottom>o){console.log("Box still outside viewport after repositioning, using fallback position");const f={top:"20px",left:"auto",right:"20px",width:"400px",height:"600px",zIndex:"2147483647"};Object.assign(t.style,f)}}const m=t.getBoundingClientRect();m.width>0&&m.height>0&&m.left>=0&&m.right<=e+1&&m.top>=0&&m.bottom<=o||(console.warn("Box visibility validation failed, forcing top-right position"),console.log("Final rect:",m),console.log("Viewport:",{width:e,height:o}),j(t))}function Z(t){if(!t)return;const n=t.querySelectorAll(".translate-button, .bn-button, .en-button"),e=t.querySelectorAll(".button-icon"),o=t.querySelector(".button-container"),r=t.querySelector(".input-container"),a=t.querySelector(".input-form"),s=t.querySelector(".chat-input");if(n.forEach(i=>{const l={padding:"12px",borderRadius:"12px",fontWeight:"600",fontSize:"14px",cursor:"pointer",border:"none",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px",minWidth:"120px",minHeight:"44px",width:"auto",height:"auto",boxSizing:"border-box",margin:"0",lineHeight:"1.5",textDecoration:"none",textTransform:"none",letterSpacing:"normal",wordSpacing:"normal",whiteSpace:"nowrap",verticalAlign:"middle",fontFamily:"inherit",fontStyle:"normal",fontVariant:"normal",transform:"none",position:"relative",overflow:"visible",color:"white"};Object.assign(i.style,l)}),e.forEach(i=>{const l={width:"16px",height:"16px",minWidth:"16px",minHeight:"16px",maxWidth:"16px",maxHeight:"16px",display:"inline-block",verticalAlign:"middle",transform:"none"};Object.assign(i.style,l)}),o){const i={display:"grid",gridTemplateColumns:"1fr 1fr",gap:"12px",width:"100%",minHeight:"44px",margin:"0",padding:"0",boxSizing:"border-box"};Object.assign(o.style,i)}if(r){const i={display:"flex",flexDirection:"column",gap:"16px",width:"100%",margin:"0",padding:"0",boxSizing:"border-box"};Object.assign(r.style,i)}if(a){const i={padding:"16px",borderTop:"1px solid #e2e8f0",background:"rgba(255, 255, 255, 0.8)",width:"100%",boxSizing:"border-box",margin:"0",flexShrink:"0"};Object.assign(a.style,i)}if(s){const i={width:"100%",padding:"12px 16px",fontSize:"14px",border:"1px solid #d1d5db",borderRadius:"12px",background:"rgba(255, 255, 255, 0.9)",color:"#374151",fontFamily:"inherit",lineHeight:"1.5",boxSizing:"border-box",outline:"none",minHeight:"44px",height:"auto",margin:"0",textDecoration:"none",textTransform:"none",letterSpacing:"normal",wordSpacing:"normal",whiteSpace:"normal",verticalAlign:"middle",fontStyle:"normal",fontVariant:"normal",transform:"none",backgroundColor:"rgba(255, 255, 255, 0.9)",backgroundImage:"none"};Object.assign(s.style,i)}console.log("Forced button sizing applied")}function At(t,n){if(console.log("createTranslationBox called with:",t,n),!$()){console.warn("Cannot create translation box: extension context invalidated");return}if(d){console.log("Translation box already open, appending text:",t,"targetLang:",n);const l=new CustomEvent("appendTranslation",{detail:{text:t,targetLang:n}});d.dispatchEvent(l);return}console.log("Creating new translation box with text:",t,"targetLang:",n);const e=K();if(!e){console.log("No valid position for translation box");return}console.log("Creating box with position:",e);const o=document.createElement("div");o.id="translation-box-container";const r={position:"fixed",top:"20px",right:"20px",left:"auto",width:"400px",height:"600px",zIndex:"2147483647",boxSizing:"border-box",pointerEvents:"auto",visibility:"visible",opacity:"1",transform:"none",filter:"none",backdropFilter:"none",margin:"0",padding:"0",border:"none",outline:"none"};Object.assign(o.style,r),o.style.setProperty("position","fixed","important"),o.style.setProperty("top","20px","important"),o.style.setProperty("right","20px","important"),o.style.setProperty("left","auto","important"),o.style.setProperty("z-index","2147483647","important"),console.log("Box styles applied:",{position:o.style.position,top:o.style.top,right:o.style.right,left:o.style.left,width:o.style.width,height:o.style.height,zIndex:o.style.zIndex}),document.body.appendChild(o),d=o,J(o),j(o),setTimeout(()=>{const l=o.getBoundingClientRect();console.log("Box position after append:",{rect:{top:l.top,left:l.left,right:l.right,bottom:l.bottom,width:l.width,height:l.height},viewport:{width:window.innerWidth,height:window.innerHeight},styles:{top:o.style.top,right:o.style.right,left:o.style.left,position:o.style.position}}),l.left<window.innerWidth-450&&(console.log("Box not in right position, forcing again"),j(o),setTimeout(()=>{o.getBoundingClientRect().left<window.innerWidth-450&&(console.log("Box still not in top-right after force, recreating"),at(o,t,n))},1e3))},50),setTimeout(()=>{H(o),Z(o),j(o)},100),F=()=>{if(d&&d.parentNode){console.log("Window resized, updating translation box position");const l=K();l?(console.log(`Updating box size on resize: width=${l.width}, height=${l.height}`),d.style.width=`${l.width}px`,d.style.height=`${l.height}px`,d.style.top=`${l.top}px`,d.style.right=`${l.right}px`,d.style.left="auto",d.style.transform="none",setTimeout(()=>{H(d),Z(d)},50)):(console.log("No valid position for box on resize, removing box"),M())}},_=()=>{d&&d.parentNode&&j(d)},window.addEventListener("resize",F),window.addEventListener("scroll",_),W=new MutationObserver(l=>{if(d&&d.parentNode){let p=!1;if(l.forEach(m=>{if(m.type==="childList"&&m.addedNodes.forEach(u=>{if(u.nodeType===1){const g=window.getComputedStyle(u);(g.position==="fixed"||g.position==="sticky")&&(p=!0);const f=u.tagName?.toLowerCase(),x=u.className?.toLowerCase()||"";(f==="header"||f==="nav"||x.includes("header")||x.includes("navbar")||x.includes("sidebar")||x.includes("menu"))&&(p=!0)}}),m.type==="attributes"&&m.attributeName==="style"){const u=m.target;if(u&&u!==d){const g=window.getComputedStyle(u);(g.position==="fixed"||g.position==="sticky")&&(p=!0)}}if(m.type==="attributes"&&m.attributeName==="class"){const u=m.target;if(u&&u!==d){const g=u.className?.toLowerCase()||"";(g.includes("header")||g.includes("navbar")||g.includes("sidebar")||g.includes("menu")||g.includes("fixed")||g.includes("sticky"))&&(p=!0)}}}),p){console.log("Website layout changed, repositioning translation box");const m=K();m&&(d.style.top=`${m.top}px`,d.style.width=`${m.width}px`,d.style.height=`${m.height}px`,d.style.right=`${m.right}px`,d.style.left="auto",d.style.transform="none"),setTimeout(()=>{H(d),Z(d)},100)}}}),W.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["style","class"]});const a=dt();(a.isProblematicWebsite||a.hasAggressiveCSS)&&(B=setInterval(()=>{d&&d.parentNode?(H(d),J(d),j(d)):(clearInterval(B),B=null)},2e3));const s=setInterval(()=>{d&&d.parentNode?d.getBoundingClientRect().left<window.innerWidth-450&&(console.log("Box moved from top-right, repositioning"),J(d),j(d),setTimeout(()=>{d.getBoundingClientRect().left<window.innerWidth-450&&(console.log("Box still not in top-right, recreating"),at(d,t,n))},2e3)):clearInterval(s)},1e3);o._positionCheckInterval=s;const i=l=>{const{iconElementBN:p,iconElementEN:m}=V(),u=A();if(d&&d.contains(l.target)){console.log("Click inside translation box, ignoring");return}if(p&&p.contains(l.target)||m&&m.contains(l.target)){console.log("Click on translate icon, ignoring");return}if(u&&u.range){const f=u.range.commonAncestorContainer,x=f.nodeType===1?f:f.parentElement;if(x&&x.contains(l.target)){console.log("Click within selected text, ignoring");return}}console.log("Outside click detected, closing translation box"),M()};document.addEventListener("click",i),o._outsideClickHandler=i,L=lt.createRoot(o),L.render(c.jsx(ut,{selectedText:t,targetLang:n,onClose:()=>{console.log("Close button clicked"),M()}}))}function M(){d&&d.parentNode&&(console.log("Removing translation box"),d._outsideClickHandler&&(document.removeEventListener("click",d._outsideClickHandler),d._outsideClickHandler=null),d._positionCheckInterval&&(clearInterval(d._positionCheckInterval),d._positionCheckInterval=null),F&&(window.removeEventListener("resize",F),F=null),_&&(window.removeEventListener("scroll",_),_=null),W&&(W.disconnect(),W=null),B&&(clearInterval(B),B=null),L&&(L.unmount(),L=null),d.parentNode.removeChild(d),d=null)}function q(){return d}function Q(t,n){if(!$())return console.warn("Cannot replace text: extension context invalidated"),!1;if(console.log("Replacing text in UI:",t,"selectionInfo:",n),!n||!t)return console.warn("Invalid selectionInfo or text, aborting replace"),!1;try{if(n.type==="input"||n.type==="translationBoxInput"||n.type==="inputLikeDiv"){const e=n.element,o=n.start,r=n.end;console.log("Input replace: current value=",e.value),console.log("Replacing from position",o,"to",r,"with:",t);const a=e.value.substring(0,o)+t+e.value.substring(r);console.log("Setting new input value:",a),e.value=a;const s=o+t.length;if(e.setSelectionRange(s,s),n.type==="translationBoxInput"){console.log("Handling translation box input replacement"),console.log("Original value:",e.value),console.log("New value:",a),console.log("Selection start:",o,"end:",r),window.lastTranslationSelection={start:o,end:r,newText:t,newValue:a};const i=new CustomEvent("translationBoxInputChange",{detail:{element:e,start:o,end:r,newText:t,newValue:a}});e.dispatchEvent(i);const l=new Event("input",{bubbles:!0});e.dispatchEvent(l),console.log("Events dispatched for translation box input")}else if(n.type==="inputLikeDiv"){console.log("Handling input-like div replacement");const i=n.selection,l=n.range;i.removeAllRanges(),i.addRange(l),l.deleteContents();const p=document.createTextNode(t);l.insertNode(p),l.setStartAfter(p),l.setEndAfter(p),i.removeAllRanges(),i.addRange(l);const m=new Event("input",{bubbles:!0});e.dispatchEvent(m),console.log("Input-like div replacement successful")}else{const i=new Event("input",{bubbles:!0});e.dispatchEvent(i)}return console.log("Input replace successful"),!0}else if(n.type==="contenteditable"){const e=n.editableElement;console.log("ContentEditable replace: currentHTML=",e.innerHTML);const o=window.getSelection();if(o.removeAllRanges(),o.addRange(n.range),!o.rangeCount)return console.warn("No valid selection range, attempting fallback"),D(t,n);const r=o.getRangeAt(0),a=r.commonAncestorContainer.nodeType===1?r.commonAncestorContainer:r.commonAncestorContainer.parentElement,s=window.getComputedStyle(a);r.deleteContents();const i=document.createTextNode(t),l=document.createElement("span");return l.style.fontFamily='"Noto Sans Bengali", "Kalpurush", Arial, sans-serif',l.style.fontSize=s.fontSize,l.style.fontWeight=s.fontWeight,l.style.color=s.color,l.style.whiteSpace="pre-wrap",l.appendChild(i),r.insertNode(l),e.normalize(),r.setStartAfter(l),r.setEndAfter(l),o.removeAllRanges(),o.addRange(r),[new Event("input",{bubbles:!0,cancelable:!0}),new Event("change",{bubbles:!0,cancelable:!0}),new InputEvent("input",{bubbles:!0,cancelable:!0,data:t,inputType:"insertText"}),new Event("keyup",{bubbles:!0,cancelable:!0})].forEach(m=>e.dispatchEvent(m)),e.focus(),console.log("ContentEditable replace successful"),!0}else{const e=window.getSelection();if(e.removeAllRanges(),e.addRange(n.range),!e.rangeCount)return console.warn("No valid selection range, attempting fallback"),D(t,n);const o=e.getRangeAt(0);console.log("Regular text replacement - range:",{startContainer:o.startContainer,startOffset:o.startOffset,endContainer:o.endContainer,endOffset:o.endOffset,commonAncestorContainer:o.commonAncestorContainer});const r=o.commonAncestorContainer.nodeType===1?o.commonAncestorContainer:o.commonAncestorContainer.parentElement;console.log("Parent element:",r);const a=r.textContent,s=e.toString();console.log("Original text:",a),console.log("Selected text:",s);const i=a.indexOf(s);if(i!==-1){const l=a.substring(0,i),p=a.substring(i+s.length);console.log("Before text:",l),console.log("After text:",p);const m=l+t+p;console.log("New text content:",m),r.textContent=m;const u=i+t.length,g=r.firstChild;if(g&&g.nodeType===Node.TEXT_NODE){const f=document.createRange();f.setStart(g,u),f.setEnd(g,u),e.removeAllRanges(),e.addRange(f)}return console.log("Regular replace successful"),!0}else return console.warn("Selected text not found in parent element, using fallback"),D(t,n)}}catch(e){return console.error("Error replacing text:",e),D(t,n)}}function D(t,n){console.log("Attempting fallback replace with:",t);try{if(document.queryCommandSupported&&document.queryCommandSupported("insertText")){console.log("Using insertText fallback");const e=window.getSelection();return e.removeAllRanges(),e.addRange(n.range),document.execCommand("insertText",!1,t),console.log("insertText fallback successful"),!0}else return navigator.clipboard&&n.type==="contenteditable"?(console.log("Using clipboard fallback for contenteditable"),navigator.clipboard.writeText(t).then(()=>{const e=window.getSelection();e.removeAllRanges(),e.addRange(n.range),document.execCommand("paste"),console.log("Clipboard fallback successful")}),!0):(console.warn("No fallback available for text replace"),!1)}catch(e){return console.error("Fallback replace failed:",e),!1}}async function xt(t,n,e){if(!$()){console.warn("Cannot handle translation: extension context invalidated"),k();return}console.log(`🔄 Handling translation for ${t} with selection:`,n?.text?.substring(0,50)+"..."),await St();const o=U();kt(o);try{const r=pt();if(!r||r.text!==n.text){console.warn("Selection changed or invalid, aborting translation"),k(),e(),et();return}n=r;try{const a=`${t}=true: ${n.text}`;console.log(`📡 Sending message to API: ${a}`),console.log(`🎯 Target language: ${t}`);const s=gt(a,t);let i="";for await(const l of s){if(!$()){console.warn("Extension context invalidated during stream processing"),k();return}console.log("Received chunk:",l),i+=l}console.log(`${t} stream translation completed, full text:`,i),Q(i,n)}catch(a){console.error(`API stream error during ${t} translation:`,a);let s=`Translation failed: ${a.message}`;a.message.includes("402")?window.AI_PROVIDER==="openrouter"?s="Translation failed: Insufficient OpenRouter credits. Please visit https://openrouter.ai/credits to add credits or use a different model.":window.AI_PROVIDER==="deepseek"&&(s="Translation failed: Insufficient DeepSeek account balance. Please visit https://platform.deepseek.com/ to top up your account or contact support at service@deepseek.com."):a.message.includes("429")&&(s="Translation failed: Rate limit exceeded. Please try again later or switch to a different model."),console.warn("Notifying user:",s),Q(s,n),k();return}}catch(r){if(console.error(`Unexpected error during ${t} translation:`,r),r.message.includes("Extension context invalidated")){console.warn("Context invalidated, aborting translation"),k();return}Q(`Translation failed: ${r.message}`,n)}finally{k(),et()}}let G=!1;window.PRIMARY_LANG="BN";window.PRIMARY_KEY="T";window.SECONDARY_KEY="E";function ht(){return new Promise(t=>{chrome.storage.sync.get(["primaryLang","primaryKey","secondaryKey"],n=>{window.PRIMARY_LANG=n.primaryLang||"BN",window.PRIMARY_KEY=n.primaryKey||"T",window.SECONDARY_KEY=n.secondaryKey||"E",console.log("Loaded settings:",window.PRIMARY_LANG,window.PRIMARY_KEY,window.SECONDARY_KEY),t()})})}function it(){const t=A();return Nt(async n=>{const e=A();e&&await xt(n,e,it)},(n,e)=>At(n,e),t)}function tt(){console.log("handleSelectionEventWrapper called"),Rt(it,T,k)}async function st(t){const n=A();n&&await xt(t,n,it)}async function nt(){if(!G)try{if(console.log("Initializing Translix extension..."),document.readyState==="loading"){console.log("Page still loading, waiting for DOMContentLoaded");return}await ht(),Tt(),T(),k();const t=document.createElement("style");t.id="translix-extension-styles",t.textContent=`
      /* Translation Box - Pure Raw CSS (No Tailwind) */
      #translation-box-container {
        position: fixed !important; /* Always viewport-relative */
        top: 20px !important; /* Always 20px from top of viewport */
        right: 20px !important; /* Always 20px from right of viewport */
        left: auto !important;
        width: 400px !important;
        height: 600px !important;
        z-index: 2147483647 !important; /* Maximum z-index to be above everything */
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
        font-size: 14px !important;
        line-height: 1.5 !important;
        /* Force isolation from website CSS */
        all: initial !important;
        box-sizing: border-box !important;
        /* Ensure proper display */
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
        pointer-events: auto !important;
        /* Prevent website CSS interference */
        transform: none !important;
        filter: none !important;
        backdrop-filter: none !important;
        /* Force proper colors */
        color: #1e293b !important;
        background: transparent !important;
        background-color: transparent !important;
        background-image: none !important;
        /* Force positioning - override any website CSS */
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        outline: none !important;
        float: none !important;
        clear: none !important;
        /* Ensure it's not affected by parent elements */
        position: fixed !important;
        top: 20px !important;
        right: 20px !important;
        left: auto !important;
        bottom: auto !important;
        /* Force stacking context and ensure it's above everything */
        isolation: isolate !important;
        contain: layout style paint !important;
        will-change: transform !important;
        transform: translateZ(0) !important;
        /* Additional properties to ensure it's above everything */
        elevation: 2147483647 !important;
        layer: 2147483647 !important;
        /* Force it to be the highest element */
        position: fixed !important;
        z-index: 2147483647 !important;
        /* Ensure it's not clipped by parent elements */
        overflow: visible !important;
        clip: auto !important;
        clip-path: none !important;
        /* Force rendering above everything */
        render-layer: 2147483647 !important;
      }

      /* Force our box to be above any website elements */
      body > #translation-box-container {
        z-index: 2147483647 !important;
        position: fixed !important;
        top: 20px !important;
        right: 20px !important;
        left: auto !important;
        bottom: auto !important;
        /* Ensure it's the highest element */
        isolation: isolate !important;
        contain: layout style paint !important;
        will-change: transform !important;
        transform: translateZ(0) !important;
        /* Force rendering above everything */
        elevation: 2147483647 !important;
        layer: 2147483647 !important;
        render-layer: 2147483647 !important;
      }

      #translation-box-container * {
        /* Reset only essential properties for child elements */
        box-sizing: border-box !important;
        font-family: inherit !important;
        /* Prevent website CSS interference */
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        outline: none !important;
        text-decoration: none !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        white-space: normal !important;
        vertical-align: baseline !important;
        /* Ensure proper font rendering */
        font-style: normal !important;
        font-variant: normal !important;
        font-weight: normal !important;
        /* Prevent any transforms */
        transform: none !important;
        /* Force proper colors */
        color: inherit !important;
        background: transparent !important;
        background-color: transparent !important;
        background-image: none !important;
      }

      /* Main Container */
      #translation-box-container .translation-box-main {
        width: 400px !important;
        height: 600px !important;
        background: #ffffff !important;
        border-radius: 16px !important;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25) !important;
        border: 1px solid #e2e8f0 !important;
        overflow: hidden !important;
        display: flex !important;
        flex-direction: column !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
        font-size: 14px !important;
        line-height: 1.5 !important;
        position: relative !important;
        /* Force proper sizing */
        min-width: 400px !important;
        min-height: 600px !important;
        max-width: 400px !important;
        max-height: 600px !important;
      }

      /* Header */
      #translation-box-container .translation-box-header {
        background: linear-gradient(to right, #2563eb, #7c3aed, #4f46e5) !important;
        color: white !important;
        padding: 12px !important;
        flex-shrink: 0 !important;
        border-bottom: none !important;
        /* Force proper sizing */
        min-height: 48px !important;
        height: 70px !important;
      }

      #translation-box-container .header-content {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        width: 100% !important;
        height: 100% !important;
      }

      #translation-box-container .header-left {
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
      }

      #translation-box-container .logo-container {
        width: 24px !important;
        height: 24px !important;
        background: white !important;
        border-radius: 8px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
        flex-shrink: 0 !important;
      }

      #translation-box-container .logo-icon {
        width: 16px !important;
        height: 16px !important;
        fill: white !important;
      }

      #translation-box-container .header-text {
        display: flex !important;
        flex-direction: column !important;
        font-size: 18px !important;
      }

      #translation-box-container .app-title {
        font-weight: bold !important;
        font-size: 14px !important;
        margin: 0 !important;
        color: white !important;
      }

      #translation-box-container .app-subtitle {
        font-size: 12px !important;
        color: #bfdbfe !important;
        margin: 0 !important;
      }

      #translation-box-container .close-button {
        padding: 6px !important;
        background: none !important;
        border: none !important;
        color: white !important;
        border-radius: 8px !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        min-width: 24px !important;
        min-height: 24px !important;
        flex-shrink: 0 !important;
      }

      #translation-box-container .close-button:hover {
        background: rgba(255, 255, 255, 0.2) !important;
        transform: scale(1.05) !important;
      }

      #translation-box-container .close-button:disabled {
        opacity: 0.5 !important;
        cursor: not-allowed !important;
      }

      #translation-box-container .close-icon {
        width: 16px !important;
        height: 16px !important;
        fill: white !important;
      }

      /* Messages Container */
      #translation-box-container .messages-container {
        flex: 1 !important;
        overflow-y: auto !important;
        padding: 12px !important;
        background: #f8fafc !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 12px !important;
        min-height: 0 !important;
        /* Force proper sizing */
        height: calc(600px - 48px - 120px) !important;
      }

      /* Input Form - Fixed Bottom Design */
      #translation-box-container .input-form {
        padding: 16px !important;
        border-top: 1px solid #e2e8f0 !important;
        background: #ffffff !important;
        flex-shrink: 0 !important;
        min-height: 120px !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: space-between !important;
        /* Force proper sizing */
        width: 100% !important;
        box-sizing: border-box !important;
      }

      #translation-box-container .input-container {
        display: flex !important;
        flex-direction: column !important;
        gap: 16px !important;
        width: 100% !important;
        height: 100% !important;
      }

      #translation-box-container .chat-input {
        width: 100% !important;
        padding: 12px 16px !important;
        font-size: 14px !important;
        border: 1px solid #d1d5db !important;
        border-radius: 12px !important;
        background: #ffffff !important;
        color: #374151 !important;
        font-family: inherit !important;
        line-height: 1.5 !important;
        box-sizing: border-box !important;
        outline: none !important;
        transition: border-color 0.2s ease-in-out !important;
        min-height: 44px !important;
        height: 44px !important;
        resize: none !important;
        /* Force proper sizing */
        margin: 0 !important;
        text-decoration: none !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        white-space: normal !important;
        vertical-align: middle !important;
        font-style: normal !important;
        font-variant: normal !important;
        transform: none !important;
        background-color: #ffffff !important;
        background-image: none !important;
      }

      #translation-box-container .chat-input:focus {
        border-color: #3b82f6 !important;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
      }

      #translation-box-container .chat-input:disabled {
        background: #f1f5f9 !important;
        background-color: #f1f5f9 !important;
        cursor: not-allowed !important;
      }

      #translation-box-container .button-container {
        display: grid !important;
        grid-template-columns: 1fr 1fr !important;
        gap: 12px !important;
        width: 100% !important;
        min-height: 44px !important;
        height: 44px !important;
        /* Force proper sizing */
        margin: 0 !important;
        padding: 0 !important;
        box-sizing: border-box !important;
        margin-top: 20px !important;
      }

      #translation-box-container .translate-button {
        padding: 12px !important;
        border-radius: 12px !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        transition: all 0.2s ease !important;
        cursor: pointer !important;
        border: none !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 8px !important;
        min-width: 140px !important;
        min-height: 44px !important;
        height: 44px !important;
        white-space: nowrap !important;
        text-decoration: none !important;
        color: white !important;
        /* Force proper sizing */
        box-sizing: border-box !important;
        margin: 0 !important;
        line-height: 1.5 !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        vertical-align: middle !important;
        font-family: inherit !important;
        font-style: normal !important;
        font-variant: normal !important;
        transform: none !important;
        position: relative !important;
        overflow: visible !important;
        background: initial !important;
        background-color: initial !important;
        background-image: initial !important;
      }

      #translation-box-container .translate-button:hover {
        transform: scale(1.02) !important;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .translate-button:disabled {
        opacity: 0.5 !important;
        cursor: not-allowed !important;
        transform: none !important;
      }

      #translation-box-container .bn-button {
        background: linear-gradient(to right, #10b981, #059669) !important;
        background-image: linear-gradient(to right, #10b981, #059669) !important;
        color: white !important;
      }

      #translation-box-container .bn-button:hover:not(:disabled) {
        background: linear-gradient(to right, #059669, #047857) !important;
        background-image: linear-gradient(to right, #059669, #047857) !important;
      }

      #translation-box-container .en-button {
        background: linear-gradient(to right, #3b82f6, #1d4ed8) !important;
        background-image: linear-gradient(to right, #3b82f6, #1d4ed8) !important;
        color: white !important;
      }

      #translation-box-container .en-button:hover:not(:disabled) {
        background: linear-gradient(to right, #1d4ed8, #1e40af) !important;
        background-image: linear-gradient(to right, #1d4ed8, #1e40af) !important;
      }

      #translation-box-container .button-icon {
        width: 16px !important;
        height: 16px !important;
        fill: currentColor !important;
        flex-shrink: 0 !important;
        /* Force icon sizing */
        min-width: 16px !important;
        min-height: 16px !important;
        max-width: 16px !important;
        max-height: 16px !important;
        display: inline-block !important;
        vertical-align: middle !important;
        transform: none !important;
      }

      /* Messages */
      #translation-box-container .message-wrapper {
        display: flex !important;
        width: 100% !important;
      }

      #translation-box-container .user-wrapper {
        justify-content: flex-end !important;
      }

      #translation-box-container .ai-wrapper {
        justify-content: flex-start !important;
      }

      #translation-box-container .message-bubble {
        max-width: 280px !important;
        padding: 12px !important;
        border-radius: 12px !important;
        font-size: 12px !important;
        position: relative !important;
        display: flex !important;
        flex-direction: column !important;
        word-wrap: break-word !important;
      }

      #translation-box-container .user-message {
        background: linear-gradient(to right, #2563eb, #7c3aed) !important;
        color: white !important;
        border-bottom-right-radius: 4px !important;
      }

      #translation-box-container .ai-message {
        background: #ffffff !important;
        color: #1e293b !important;
        border: 1px solid #e2e8f0 !important;
        border-bottom-left-radius: 4px !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .error-message {
        background: #fef2f2 !important;
        border: 1px solid #fecaca !important;
        color: #991b1b !important;
        border-radius: 8px !important;
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .message-content {
        display: flex !important;
        align-items: flex-start !important;
        gap: 8px !important;
        margin-bottom: 8px !important;
      }

      #translation-box-container .message-icon {
        width: 20px !important;
        height: 20px !important;
        border-radius: 50% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        flex-shrink: 0 !important;
        margin-top: 2px !important;
      }

      #translation-box-container .user-icon {
        background: rgba(255, 255, 255, 0.2) !important;
      }

      #translation-box-container .ai-icon {
        background: linear-gradient(to right, #3b82f6, #7c3aed) !important;
      }

      #translation-box-container .error-icon {
        background: #ef4444 !important;
      }

      #translation-box-container .icon-svg {
        width: 12px !important;
        height: 12px !important;
        color: white !important;
        fill: white !important;
      }

      #translation-box-container .message-text-container {
        flex: 1 !important;
        min-width: 0 !important;
      }

      #translation-box-container .message-text {
        word-break: break-words !important;
        font-size: 12px !important;
        line-height: 1.5 !important;
        margin: 0 !important;
        white-space: pre-wrap !important;
      }

      #translation-box-container .error-text {
        font-weight: 500 !important;
      }

      /* Troubleshooting Section */
      #translation-box-container .troubleshooting-section {
        margin-top: 8px !important;
        padding: 8px !important;
        background: #fffbeb !important;
        border: 1px solid #fde68a !important;
        border-radius: 4px !important;
        font-size: 12px !important;
        color: #92400e !important;
      }

      #translation-box-container .troubleshooting-title {
        font-weight: 500 !important;
        margin: 0 0 4px 0 !important;
      }

      #translation-box-container .troubleshooting-list {
        list-style: disc !important;
        list-style-position: inside !important;
        margin: 0 !important;
        padding: 0 !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 2px !important;
      }

      #translation-box-container .troubleshooting-list li {
        margin: 0 !important;
      }

      /* Copy Button */
      #translation-box-container .copy-button {
        position: absolute !important;
        bottom: 4px !important;
        right: 4px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        padding: 2px !important;
        border-radius: 3px !important;
        font-size: 0 !important;
        font-weight: 500 !important;
        transition: all 0.2s ease !important;
        opacity: 0 !important;
        cursor: pointer !important;
        border: none !important;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) !important;
        width: 16px !important;
        height: 16px !important;
        z-index: 10 !important;
      }

      #translation-box-container .message-bubble:hover .copy-button {
        opacity: 1 !important;
        transform: scale(1.1) !important;
      }

      #translation-box-container .user-copy {
        background: rgba(255, 255, 255, 0.9) !important;
        color: #2563eb !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        font-weight: 600 !important;
      }

      #translation-box-container .user-copy:hover {
        background: rgba(255, 255, 255, 1) !important;
        transform: scale(1.1) !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.25) !important;
      }

      #translation-box-container .ai-copy {
        background: #3b82f6 !important;
        color: white !important;
        font-weight: 600 !important;
      }

      #translation-box-container .ai-copy:hover {
        background: #2563eb !important;
        transform: scale(1.1) !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.25) !important;
      }

      #translation-box-container .copy-icon {
        width: 10px !important;
        height: 10px !important;
        fill: currentColor !important;
        stroke: currentColor !important;
        stroke-width: 1.5 !important;
      }

      /* Loading States */
      #translation-box-container .loading-container {
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
        padding: 24px 0 !important;
        height: 100% !important;
      }

      #translation-box-container .loading-content {
        text-align: center !important;
      }

      #translation-box-container .loading-spinner {
        width: 24px !important;
        height: 24px !important;
        border: 4px solid #cbd5e1 !important;
        border-top: 4px solid #3b82f6 !important;
        border-radius: 50% !important;
        animation: spin 1s linear infinite !important;
        margin: 0 auto 12px !important;
      }

      #translation-box-container .loading-text {
        color: #475569 !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        margin: 0 !important;
      }

      #translation-box-container .loading-message-bubble {
        background: #ffffff !important;
        border: 1px solid #e2e8f0 !important;
        border-radius: 12px !important;
        border-bottom-left-radius: 4px !important;
        padding: 12px !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .loading-message-content {
        display: flex !important;
        align-items: center !important;
        gap: 4px !important;
      }

      #translation-box-container .streaming-content {
        display: flex !important;
        gap: 4px !important;
      }

      #translation-box-container .streaming-text {
        font-size: 12px !important;
        color: #374151 !important;
        margin: 0 !important;
      }

      #translation-box-container .streaming-cursor {
        animation: blink 1s infinite !important;
        color: #3b82f6 !important;
        font-weight: bold !important;
      }

      #translation-box-container .loading-dots {
        display: flex !important;
        gap: 4px !important;
      }

      #translation-box-container .loading-dot {
        width: 6px !important;
        height: 6px !important;
        background: #9ca3af !important;
        border-radius: 50% !important;
        animation: bounce 1.4s infinite ease-in-out !important;
      }

      #translation-box-container .dot-1 {
        animation-delay: -0.32s !important;
      }

      #translation-box-container .dot-2 {
        animation-delay: -0.16s !important;
      }

      #translation-box-container .dot-3 {
        animation-delay: 0s !important;
      }

      #translation-box-container .loading-status {
        font-size: 12px !important;
        color: #6b7280 !important;
        margin-left: 8px !important;
      }

      /* Copy Alert */
      #translation-box-container .copy-alert {
        position: fixed !important;
        top: 80px !important;
        right: 16px !important;
        background: linear-gradient(to right, #10b981, #059669) !important;
        color: white !important;
        padding: 12px 16px !important;
        border-radius: 12px !important;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25) !important;
        z-index: 9999 !important;
        animation: fadeIn 0.3s ease-out !important;
        border: 1px solid #34d399 !important;
      }

      #translation-box-container .copy-alert-content {
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
      }

      #translation-box-container .copy-alert-icon {
        width: 20px !important;
        height: 20px !important;
        background: rgba(255, 255, 255, 0.2) !important;
        border-radius: 50% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
      }

      #translation-box-container .check-icon {
        width: 12px !important;
        height: 12px !important;
        color: white !important;
        fill: white !important;
      }

      #translation-box-container .copy-alert-text {
        font-size: 14px !important;
        font-weight: 600 !important;
      }

      /* Animations */
      @keyframes spin {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(360deg);
        }
      }

      @keyframes bounce {
        0%, 80%, 100% {
          transform: scale(0);
        }
        40% {
          transform: scale(1);
        }
      }

      @keyframes blink {
        0%, 50% {
          opacity: 1;
        }
        51%, 100% {
          opacity: 0;
        }
      }

      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(-10px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      /* Custom Scrollbar */
      #translation-box-container .messages-container::-webkit-scrollbar {
        width: 8px !important;
      }

      #translation-box-container .messages-container::-webkit-scrollbar-track {
        background: rgba(241, 245, 249, 0.3) !important;
        border-radius: 10px !important;
        margin: 4px 0 !important;
      }

      #translation-box-container .messages-container::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%) !important;
        border-radius: 10px !important;
        border: 1px solid rgba(255, 255, 255, 0.8) !important;
        transition: all 0.3s ease !important;
      }

      #translation-box-container .messages-container::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #cbd5e1 0%, #94a3b8 100%) !important;
        transform: scale(1.05) !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1) !important;
      }

      /* For Firefox */
      #translation-box-container .messages-container {
        scrollbar-width: thin !important;
        scrollbar-color: #cbd5e1 #f1f5f9 !important;
      }
    `,document.getElementById("translix-extension-styles")||document.head.appendChild(t),G=!0,console.log("Translix extension initialized successfully")}catch(t){console.error("Error initializing Translix extension:",t)}}function ot(){if(G)try{document.addEventListener("selectionchange",()=>{console.log("Selection change event triggered"),setTimeout(tt,100)}),document.addEventListener("mouseup",n=>{console.log("Mouse up event triggered");const{iconElementBN:e,iconElementEN:o}=V(),r=q();if(e&&e.contains(n.target)||o&&o.contains(n.target)||r&&r.contains(n.target)){console.log("Mouse up on icon or box, ignoring global handler");return}if(ft()){console.log("Ignoring global mouseup during long press processing");return}console.log("Calling handleSelectionEventWrapper from mouseup"),setTimeout(tt,150)}),document.addEventListener("keyup",n=>{(n.key==="Shift"||n.key.includes("Arrow"))&&setTimeout(tt,100)}),document.addEventListener("keydown",async n=>{if(n.ctrlKey&&console.log("Ctrl key pressed with:",n.key,"Current settings:",{PRIMARY_KEY:window.PRIMARY_KEY,SECONDARY_KEY:window.SECONDARY_KEY,PRIMARY_LANG:window.PRIMARY_LANG}),n.ctrlKey&&!n.altKey&&!n.shiftKey&&!n.metaKey){const e=n.key.toUpperCase();if(console.log("Checking key:",e,"against PRIMARY_KEY:",window.PRIMARY_KEY,"SECONDARY_KEY:",window.SECONDARY_KEY),e===window.PRIMARY_KEY){n.preventDefault(),console.log(`Ctrl+${window.PRIMARY_KEY} pressed for ${window.PRIMARY_LANG} translation`);const o=A();o&&o.text?await st(window.PRIMARY_LANG):console.log(`No text selected, ignoring Ctrl+${window.PRIMARY_KEY}`)}else if(e===window.SECONDARY_KEY){n.preventDefault(),console.log(`Ctrl+${window.SECONDARY_KEY} pressed for EN translation`);const o=A();o&&o.text?await st("EN"):console.log(`No text selected, ignoring Ctrl+${window.SECONDARY_KEY}`)}}}),document.addEventListener("scroll",()=>{const{iconElementBN:n,iconElementEN:e}=V(),o=A();if(n&&e&&o){const r=U();r?(n.style.top=`${r.top}px`,n.style.left=`${r.left}px`,e.style.top=`${r.top}px`,e.style.left=`${r.left+34}px`):(console.log("No valid position for icons on scroll, removing icons"),T(),k())}},{passive:!0});const t=wt(()=>{const n=q();if(n){const e=K();e?(console.log(`Updating box position on resize: top=${e.top}, left=${e.left}, right=${e.right}, width=${e.width}, height=${e.height}`),n.style.top=`${e.top}px`,n.style.width=`${e.width}px`,n.style.height=`${e.height}px`,e.right!=="auto"?(n.style.right=`${e.right}px`,n.style.left="auto",n.style.transform="none"):e.left!=="auto"?(n.style.left=`${e.left}px`,n.style.right="auto",n.style.transform="none"):(n.style.left="50%",n.style.right="auto",n.style.transform="translateX(-50%)")):(console.log("No valid position for box on resize, removing box"),M())}},100);document.addEventListener("resize",()=>{console.log("Window resized, updating box size or removing icons and box"),q()&&t();const{iconElementBN:e,iconElementEN:o}=V(),r=A();if(e&&o&&r){const a=U();a?(e.style.top=`${a.top}px`,e.style.left=`${a.left}px`,o.style.top=`${a.top}px`,o.style.left=`${a.left+34}px`):(T(),k())}else T(),k()},{passive:!0}),window.addEventListener("beforeunload",()=>{console.log("Page unloading, removing icons and box"),T(),k(),M()}),chrome.storage.onChanged.addListener((n,e)=>{e==="sync"&&(n.primaryLang||n.primaryKey||n.secondaryKey)&&(console.log("Settings changed, reloading..."),ht().then(()=>{console.log("Settings reloaded:",window.PRIMARY_LANG,window.PRIMARY_KEY,window.SECONDARY_KEY)}))}),console.log("Translix event listeners added successfully")}catch(t){console.error("Error adding Translix event listeners:",t)}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",async()=>{await nt(),ot()}):(async()=>(await nt(),ot()))();window.addEventListener("load",async()=>{G||(await nt(),ot())});window.AI_PROVIDER="openrouter";console.log("Translix content script loaded successfully");
