import{A as at,l as tt,r as E,a as St,b as Nt,V as st,j as c,c as Rt,i as Tt,d as dt}from"./index-YmCB05Oc.js";function At(t,o){let e;return function(...i){const r=()=>{clearTimeout(e),t(...i)};clearTimeout(e),e=setTimeout(r,o)}}function mt(t){if(!t)return!1;if(t.tagName==="TEXTAREA"||t.tagName==="INPUT"&&/^(text|search|url|tel|email|password)$/i.test(t.type))return!0;if(t.tagName==="DIV"||t.tagName==="SPAN"){if(t.contentEditable==="true"||t.isContentEditable)return!0;const o=t.getAttribute("role");if(o==="textbox"||o==="combobox")return!0;const n=(t.className||"").toLowerCase();if(n.includes("input")||n.includes("textbox")||n.includes("editor")||n.includes("composer")||n.includes("textarea")||n.includes("post")||n.includes("comment")||n.includes("message")||t.getAttribute("data-testid")&&t.getAttribute("data-testid").toLowerCase().includes("input")||t.oninput||t.onkeydown||t.onkeyup||t.onpaste)return!0}return!1}function It(){const t=document.activeElement;if(mt(t)){if(t.tagName==="INPUT"||t.tagName==="TEXTAREA"){const i=t.selectionStart,r=t.selectionEnd;if(i===r)return null;const s=window.getComputedStyle(t),a=document.createElement("div");a.style.position="absolute",a.style.visibility="hidden",a.style.height="auto",a.style.width="auto",a.style.whiteSpace=t.tagName==="TEXTAREA"?"pre-wrap":"nowrap",["fontFamily","fontSize","fontWeight","letterSpacing","lineHeight","padding"].forEach(x=>{a.style[x]=s[x]}),document.body.appendChild(a);const l=t.value.substring(0,i);a.textContent=l;const m=t.getBoundingClientRect(),g=a.getBoundingClientRect();return document.body.removeChild(a),{left:m.left+(l.length>0?Math.min(g.width,m.width-20):0),top:m.top,right:m.left+Math.min(g.width+50,m.width),bottom:m.bottom,width:Math.min(50,m.width-(g.width||0)),height:m.height}}if(t.tagName==="DIV"||t.tagName==="SPAN"){const i=window.getSelection();if(!i||i.isCollapsed)return null;const s=i.getRangeAt(0).getBoundingClientRect();if(s.width>0&&s.height>0)return{left:s.left,top:s.top,right:s.right,bottom:s.bottom,width:s.width,height:s.height};const a=t.getBoundingClientRect();return{left:a.left,top:a.top,right:a.right,bottom:a.bottom,width:a.width,height:a.height}}}const o=window.getSelection();if(!o.rangeCount)return null;const e=o.getRangeAt(0),n=e.getBoundingClientRect();if(n.width===0&&n.height===0){const i=e.commonAncestorContainer;return(i.nodeType===1?i:i.parentElement).getBoundingClientRect()}return n}function gt(){const t=document.activeElement;if(mt(t)){if(t.tagName==="INPUT"||t.tagName==="TEXTAREA"){const a=t.selectionStart,l=t.selectionEnd;if(a!==l){const m=t.value.substring(a,l);return console.log("Input selection:",m),t.closest("#translation-box-container")?(console.log("Selection detected in translation box input"),{text:m,type:"translationBoxInput",element:t,start:a,end:l,originalValue:t.value}):{text:m,type:"input",element:t,start:a,end:l,originalValue:t.value}}return null}if(t.tagName==="DIV"||t.tagName==="SPAN"){const a=window.getSelection();if(!a||a.isCollapsed)return null;const l=a.toString();return l?(console.log("Input-like div selection:",l),t.closest("#translation-box-container")?(console.log("Selection detected in translation box input-like div"),{text:l,type:"translationBoxInput",element:t,start:0,end:l.length,originalValue:t.textContent||t.innerText}):{text:l,type:"inputLikeDiv",element:t,selection:a,range:a.getRangeAt(0).cloneRange(),originalValue:t.textContent||t.innerText}):null}}const o=window.getSelection();if(!o||o.isCollapsed)return null;const e=o.toString();if(!e)return null;const n=o.getRangeAt(0),i=n.commonAncestorContainer;let s=i.nodeType===1?i:i.parentElement;for(;s&&!jt(s);)s=s.parentElement;return s?(console.log("ContentEditable selection:",e),{text:e,type:"contenteditable",selection:o,range:n.cloneRange(),editableElement:s,originalHTML:s.innerHTML}):(console.log("Regular selection:",e),{text:e,type:"regular",selection:o,range:n.cloneRange()})}function jt(t){return t&&(t.contentEditable==="true"||t.isContentEditable||t.getAttribute&&t.getAttribute("contenteditable")==="true")}function V(){const t=It();if(!t)return null;const o=window.scrollX||document.documentElement.scrollLeft,e=window.scrollY||document.documentElement.scrollTop,n=window.innerWidth-t.right;t.left;const i=window.innerHeight-t.bottom,r=t.top;let s,a;i>=35?(s=t.bottom+e+5,a=t.left+o+t.width/2-12):n>=35?(s=t.top+e+t.height/2-12,a=t.right+o+5):r>=35?(s=t.top+e-30,a=t.left+o+t.width/2-12):(s=t.top+e+t.height/2-12,a=t.left+o-30);const l=24,m=24,x=l+34+l,d=window.innerWidth+o-x-10,h=window.innerHeight+e-m-10,b=o+10,S=e+10;return a=Math.max(b,Math.min(a,d)),s=Math.max(S,Math.min(s,h)),(a<b||a>d||s<S||s>h)&&(console.log("Icon position was outside viewport, repositioning to safe area"),s=Math.floor((window.innerHeight-m)/2)+e,a=Math.floor((window.innerWidth-x)/2)+o,a=Math.max(b,Math.min(a,d)),s=Math.max(S,Math.min(s,h))),{top:s,left:a}}function ut(){const t=document.body,o=document.documentElement,e={hasFixedHeader:!1,hasSidebar:!1,hasOverflowHidden:!1,bodyOverflow:"visible",htmlOverflow:"visible",isFiverr:!1,isProblematicWebsite:!1,hasAggressiveCSS:!1,hasFixedElements:[],viewportInfo:{width:window.innerWidth,height:window.innerHeight,scrollX:window.scrollX||document.documentElement.scrollLeft,scrollY:window.scrollY||document.documentElement.scrollTop}},n=window.location.hostname.toLowerCase();n.includes("fiverr.com")&&(e.isFiverr=!0,e.isProblematicWebsite=!0,e.hasAggressiveCSS=!0),(n.includes("upwork.com")||n.includes("freelancer.com")||n.includes("guru.com")||n.includes("peopleperhour.com")||n.includes("linkedin.com")||n.includes("facebook.com")||n.includes("twitter.com")||n.includes("instagram.com")||n.includes("youtube.com")||n.includes("github.com")||n.includes("stackoverflow.com"))&&(e.isProblematicWebsite=!0,e.hasAggressiveCSS=!0),["header",".header",".navbar",".nav",".navigation",".top-bar",".topbar",'[class*="header"]','[class*="navbar"]','[class*="nav"]','[class*="menu"]','[class*="toolbar"]','[class*="bar"]','[class*="fixed"]','[class*="sticky"]'].forEach(x=>{try{document.querySelectorAll(x).forEach(h=>{const b=window.getComputedStyle(h);(b.position==="fixed"||b.position==="sticky")&&(e.hasFixedHeader=!0,e.hasFixedElements.push({element:h,position:b.position,top:b.top,height:h.offsetHeight,zIndex:parseInt(b.zIndex)||0}))})}catch{}}),[".sidebar",".aside",".panel",".drawer",".drawer-side",'[class*="sidebar"]','[class*="aside"]','[class*="panel"]','[class*="drawer"]','[class*="menu"]','[class*="nav"]'].forEach(x=>{try{document.querySelectorAll(x).forEach(h=>{const b=window.getComputedStyle(h),S=h.getBoundingClientRect();S.width<300&&S.height>window.innerHeight*.5&&(e.hasSidebar=!0,e.hasFixedElements.push({element:h,position:b.position,left:b.left,width:S.width,zIndex:parseInt(b.zIndex)||0}))})}catch{}});const s=window.getComputedStyle(t),a=window.getComputedStyle(o);e.bodyOverflow=s.overflow,e.htmlOverflow=a.overflow,e.hasOverflowHidden=s.overflow==="hidden"||a.overflow==="hidden";const l=document.querySelectorAll("*");let m=0,g=0;return l.forEach(x=>{const d=window.getComputedStyle(x);d.zIndex&&parseInt(d.zIndex)>1e3&&(m++,g++),(d.position==="fixed"||d.position==="absolute")&&m++}),(m>50||g>10)&&(e.hasAggressiveCSS=!0),e.hasFixedElements.sort((x,d)=>d.zIndex-x.zIndex),e}function D(){const t=window.innerWidth,o=window.innerHeight,e=400,n=Math.min(600,Math.max(400,Math.floor(o*.8)));ut();let i={width:e,height:n,top:20,left:"auto",right:20,zIndex:2147483647};return n>o-40&&(i.height=o-40,i.top=20),e>t-40&&(i.width=t-40,i.right=20,i.left="auto"),console.log(`Calculated viewport-relative top-right box position: top=${i.top}, left=${i.left}, right=${i.right}, width=${i.width}, height=${i.height}, viewport=${t}x${o}`),i}function Lt(t){console.log("Showing loading indicator"),document.querySelectorAll("[data-translate-icon]").forEach(n=>{n.parentNode&&n.parentNode.removeChild(n)});const e=document.createElement("div");e.id="loading-indicator",e.style.position="absolute",e.style.top=`${t.top}px`,e.style.left=`${t.left}px`,e.style.width="50px",e.style.height="32px",e.style.background="rgba(255, 255, 255, 0.95)",e.style.border="1px solid rgba(0, 0, 0, 0.1)",e.style.borderRadius="16px",e.style.boxShadow="0 4px 20px rgba(0, 0, 0, 0.15)",e.style.zIndex="2147483647",e.style.display="flex",e.style.alignItems="center",e.style.justifyContent="center",e.style.backdropFilter="blur(10px)",e.style.gap="4px";for(let n=0;n<3;n++){const i=document.createElement("div");i.style.width="6px",i.style.height="6px",i.style.borderRadius="50%",i.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",i.style.animation=`tranai-dot-bounce 1.4s ease-in-out ${n*.2}s infinite`,e.appendChild(i)}if(!document.getElementById("tranai-loading-styles")){const n=document.createElement("style");n.id="tranai-loading-styles",n.textContent=`
      @keyframes tranai-dot-bounce {
        0%, 80%, 100% {
          transform: translateY(0px);
          opacity: 0.5;
        }
        40% {
          transform: translateY(-8px);
          opacity: 1;
        }
      }
    `,document.head.appendChild(n)}return document.body.appendChild(e),e}function C(){const t=document.getElementById("loading-indicator");t&&t.parentNode?(console.log("Removing loading indicator"),t.parentNode.removeChild(t)):console.log("Loading indicator not found or already removed");const o=document.getElementById("tranai-loading-styles");o&&o.parentNode&&o.parentNode.removeChild(o)}async function Pt(){try{return await tt()}catch(t){return console.error("Failed to load settings:",t),null}}function zt(){try{return!!chrome.runtime.id}catch(t){return console.error("Extension context invalidated:",t),!1}}async function Mt(t,o,e=5e3){const n=new AbortController,i=setTimeout(()=>n.abort(),e);try{const r=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(o),signal:n.signal});if(clearTimeout(i),!r.ok)throw new Error(`HTTP error! status: ${r.status}`);return await r.json()}catch(r){throw clearTimeout(i),r.name==="AbortError"?new Error("Request timeout"):r}}async function xt(t,o=null,e=!1){if(!zt())throw new Error("Extension context invalidated");try{let n=o;if(!n&&t.includes("=")){const a=t.match(/^(\w+)=true:/);a&&(n=a[1])}const i=await Pt(),r={...at.requestBody,userMessage:t,language:n||"EN",stream:!1};i&&(i.provider&&(r.provider=i.provider),i.apiKey&&(r.apiKey=i.apiKey),i.model&&(r.model=i.model));const s=await Mt(at.baseURL,r,5e3);return s.response||s.message||s.text||JSON.stringify(s)}catch(n){throw console.error(`API request error: ${n.message}`),new Error(`API request failed: ${n.message}`)}}const Bt=({isVisible:t=!1,onClose:o})=>{const[e,n]=E.useState(null),[i,r]=E.useState(!1);E.useEffect(()=>{if(t){const l=setTimeout(()=>{s()},1e3);return()=>clearTimeout(l)}},[t]);const s=async()=>{try{r(!0),console.log("Checking for updates...");const l=await St.get(`${Nt}/api/updates`);console.log("Update check response:",l?.data),l?.data?.data&&st!==l.data.data.version?(console.log("New update available:",l.data.data),n(l.data.data),setTimeout(()=>{n(null)},8e3)):console.log("No updates available. Current version:",st)}catch(l){console.log("Error checking for updates:",l)}finally{r(!1)}},a=()=>{n(null)};return!t||i||!e?null:c.jsxs("div",{className:"update-card-overlay","data-translix-update-card":"true",children:[c.jsx("div",{className:"update-card-backdrop","data-translix-update-card":"true",onClick:l=>{l.stopPropagation(),a()}}),c.jsxs("div",{className:"update-card-container","data-translix-update-card":"true",children:[c.jsxs("div",{className:"update-card-header",children:[c.jsxs("div",{className:"update-card-header-left",children:[c.jsx("div",{className:"update-card-flag-container",children:e?.flagUrl?c.jsx("img",{src:e.flagUrl,alt:"Flag",className:"update-card-flag"}):c.jsx("svg",{className:"update-card-flag-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M13 10V3L4 14h7v7l9-11h-7z"})})}),c.jsxs("div",{className:"update-card-header-text",children:[c.jsx("h3",{className:"update-card-title",children:"Translix"}),c.jsx("p",{className:"update-card-subtitle",children:"নতুন আপডেট!"})]})]}),c.jsx("button",{onClick:l=>{l.stopPropagation(),a()},className:"update-card-close-button",title:"Close",children:c.jsx("svg",{className:"update-card-close-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]}),c.jsxs("div",{className:"update-card-body",children:[c.jsx("h4",{className:"update-card-content-title",children:e.title}),c.jsx("p",{className:"update-card-content-description",children:e.description})]}),c.jsxs("div",{className:"update-card-actions",children:[c.jsx("button",{onClick:l=>{l.stopPropagation(),a()},className:"update-card-cancel-button",children:e?.buttonText[0]||"Cancel"}),c.jsx("a",{href:e.link,target:"_blank",rel:"noopener noreferrer",className:"update-card-update-button",children:e?.buttonText[1]||"Update"})]})]})]})},ft=({selectedText:t,targetLang:o,onClose:e})=>{const[n,i]=E.useState([]),[r,s]=E.useState(!1),[a,l]=E.useState(""),[m,g]=E.useState(""),[x,d]=E.useState(!1),[h,b]=E.useState(!0),[S,vt]=E.useState("BN"),[Ht,Et]=E.useState("Bengali"),it=async()=>{try{if(typeof chrome<"u"&&chrome.storage&&chrome.storage.sync){const u=await new Promise(v=>{chrome.storage.sync.get(["primaryLang"],v)});u.primaryLang&&(vt(u.primaryLang),Et({BN:"Bengali",HI:"Hindi",UR:"Urdu",AR:"Arabic",ZH:"Chinese",ES:"Spanish",FR:"French",DE:"German",IT:"Italian",JA:"Japanese",KO:"Korean",PT:"Portuguese",RU:"Russian",TH:"Thai",VI:"Vietnamese",TR:"Turkish",NL:"Dutch",SV:"Swedish",NO:"Norwegian",DA:"Danish",FI:"Finnish",PL:"Polish",CS:"Czech",HU:"Hungarian",RO:"Romanian",BG:"Bulgarian",HR:"Croatian",SK:"Slovak",SL:"Slovenian",ET:"Estonian",LV:"Latvian",LT:"Lithuanian",MT:"Maltese",EL:"Greek",HE:"Hebrew",FA:"Persian",ID:"Indonesian",MS:"Malay",TL:"Filipino",SW:"Swahili",AM:"Amharic",HA:"Hausa",IG:"Igbo",YO:"Yoruba",ZU:"Zulu",AF:"Afrikaans",XH:"Xhosa",ST:"Sesotho",TN:"Tswana",TS:"Tsonga",VE:"Venda",NR:"Ndebele",SS:"Swati",ND:"Ndebele",EN:"English"}[u.primaryLang]||u.primaryLang))}}catch(u){console.error("Error loading primary language:",u)}};E.useEffect(()=>{const u=f=>{const{text:y,targetLang:k}=f.detail;y&&k===o&&i(P=>[...P,y])},v=f=>{const{newValue:y,start:k,end:P,newText:Wt}=f.detail;g(y)},w=document.getElementById("translation-box-container");return w&&(w.addEventListener("appendTranslation",u),w.addEventListener("translationBoxInputChange",v)),t&&o&&(i([t]),it(),setTimeout(async()=>{try{const f=await tt();if(!f||!f.provider){const k="Provider settings not found. Please configure your provider first.";i(P=>[...P,k]);return}const y=await Rt(f.provider);if(!y||y.trim()===""){const k="API key not found. Please check your provider settings.";i(P=>[...P,k]);return}await rt(t,o)}catch(f){const y=`Error: ${f.message}`;i(k=>[...k,y])}},100)),()=>{w&&(w.removeEventListener("appendTranslation",u),w.removeEventListener("translationBoxInputChange",v))}},[t,o]),E.useEffect(()=>{it()},[]),E.useEffect(()=>{const u=f=>{if(h)return;const y=document.getElementById("translation-box-container");y&&!y.contains(f.target)&&e()},v=()=>{if(h)return;const f=window.getSelection();f&&f.toString().trim()&&e()},w=f=>{f.key==="Escape"&&(h?b(!1):e())};return document.addEventListener("mousedown",u),document.addEventListener("mouseup",v),document.addEventListener("keydown",w),()=>{document.removeEventListener("mousedown",u),document.removeEventListener("mouseup",v),document.removeEventListener("keydown",w)}},[e,h]),E.useEffect(()=>{const u=document.querySelector("#translation-box-container .chat-input");if(u&&u.value!==m&&(u.value=m,window.lastTranslationSelection)){const{start:v,newText:w}=window.lastTranslationSelection,f=v+w.length;u.setSelectionRange(f,f),window.lastTranslationSelection=null}},[m]);const rt=async(u,v)=>{if(await tt(),!await Tt()){const f="First configure your provider in settings to start translating.";i(y=>[...y,f]);return}s(!0),l("");try{const f=`${v}=true: ${u}`,y=await xt(f,v,!1);i(k=>[...k,y]),l("")}catch(f){const y=`Error: ${f.message}. Please check your API configuration.`;i(k=>[...k,y]),l("")}s(!1)},G=async u=>{if(!m.trim())return;const v=m.trim();i(w=>[...w,v]),g(""),l(""),s(!0);try{await rt(v,u)}catch(w){i(f=>[...f,`Error: ${w.message}`])}finally{s(!1)}},kt=async u=>{try{await navigator.clipboard.writeText(u),d(!0),setTimeout(()=>d(!1),2e3)}catch(v){console.error("Failed to copy text:",v)}},Ct={width:"400px",height:"600px"};return c.jsxs("div",{className:"translation-box-main",style:Ct,children:[c.jsx(Bt,{isVisible:h,onClose:()=>{b(!1)}}),c.jsx("div",{className:"translation-box-header",children:c.jsxs("div",{className:"header-content",children:[c.jsxs("div",{className:"header-left",children:[c.jsx("div",{className:"logo-container",children:c.jsx("img",{src:"https://i.postimg.cc/QVLmn52N/logo.png",alt:"Translix Logo",className:"logo-icon",onError:u=>{u.target.outerHTML=`
                    <svg class="logo-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"></path>
                    </svg>
                  `}})}),c.jsxs("div",{className:"header-text",children:[c.jsx("h3",{className:"app-title",children:"Translix"}),c.jsx("p",{className:"app-subtitle",children:"Smart Translation"})]})]}),c.jsx("button",{onClick:e,disabled:r,className:"close-button",title:"Close",children:c.jsx("svg",{className:"close-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]})}),c.jsxs("div",{className:"messages-container",children:[n.length===0&&!r&&c.jsx("div",{className:"loading-container",children:c.jsxs("div",{className:"loading-content",children:[c.jsx("div",{className:"loading-spinner"}),c.jsx("p",{className:"loading-text",children:"Loading Translix..."})]})}),n.map((u,v)=>{const w=v%2===0,f=u.startsWith("Error:")||u.startsWith("Configuration error:")||u.includes("configure");let y="message-bubble";return f?y+=" error-message":w?y+=" user-message":y+=" ai-message",c.jsx("div",{className:w?"message-wrapper user-wrapper":"message-wrapper ai-wrapper",children:c.jsxs("div",{className:y,children:[c.jsxs("div",{className:"message-content",children:[c.jsx("div",{className:`message-icon ${f?"error-icon":w?"user-icon":"ai-icon"}`,children:f?c.jsx("svg",{className:"icon-svg",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z"})}):w?c.jsx("svg",{className:"icon-svg",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"})}):c.jsx("svg",{className:"icon-svg",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"})})}),c.jsxs("div",{className:"message-text-container",children:[c.jsx("p",{className:`message-text ${f?"error-text":""}`,children:u}),f&&c.jsxs("div",{className:"troubleshooting-section",children:[c.jsx("p",{className:"troubleshooting-title",children:"💡 Troubleshooting:"}),c.jsxs("ul",{className:"troubleshooting-list",children:[c.jsx("li",{children:"Check if your API server is running"}),c.jsx("li",{children:"Verify your API key and provider settings"}),c.jsx("li",{children:"Try refreshing the page and try again"}),u.includes("configure")&&c.jsx("li",{children:c.jsx("button",{onClick:()=>{},style:{background:"linear-gradient(to right, #3b82f6, #1d4ed8)",color:"white",border:"none",borderRadius:"8px",padding:"8px 16px",cursor:"pointer",fontSize:"12px",marginTop:"8px"},children:"🔄 Retry Translation"})})]})]})]})]}),c.jsx("button",{className:`copy-button ${w?"user-copy":"ai-copy"}`,onClick:()=>kt(u),title:"Copy message",children:c.jsx("svg",{className:"copy-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"})})})]})},v)}),r&&c.jsx("div",{className:"message-wrapper ai-wrapper",children:c.jsx("div",{className:"loading-message-bubble",children:c.jsxs("div",{className:"loading-message-content",children:[a?c.jsx("div",{className:"streaming-content",children:c.jsxs("p",{className:"streaming-text",children:[a,c.jsx("span",{className:"streaming-cursor",children:"|"})]})}):c.jsxs("div",{className:"loading-dots",children:[c.jsx("div",{className:"loading-dot dot-1"}),c.jsx("div",{className:"loading-dot dot-2"}),c.jsx("div",{className:"loading-dot dot-3"})]}),c.jsx("span",{className:"loading-status",children:a?"Translating...":"Starting translation..."})]})})})]}),x&&c.jsx("div",{className:"copy-alert",children:c.jsxs("div",{className:"copy-alert-content",children:[c.jsx("div",{className:"copy-alert-icon",children:c.jsx("svg",{className:"check-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M5 13l4 4L19 7"})})}),c.jsx("span",{className:"copy-alert-text",children:"Copied to clipboard!"})]})}),c.jsx("div",{className:"input-form",children:c.jsxs("div",{className:"input-container",children:[c.jsx("input",{type:"text",value:m,onChange:u=>g(u.target.value),onKeyDown:u=>{u.key==="Enter"&&!u.shiftKey&&m.trim()&&(u.preventDefault(),G(S))},className:"chat-input",placeholder:"Type a message to translate...",disabled:r}),c.jsxs("div",{className:"button-container",children:[c.jsxs("button",{type:"button",onClick:()=>{console.log("🔘 Primary button clicked!"),G(S)},className:"translate-button bn-button",style:{cursor:"pointer",pointerEvents:"auto"},children:[c.jsx("svg",{className:"button-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"})}),"Translate to ",S]}),c.jsxs("button",{type:"button",onClick:()=>{console.log("🔘 English button clicked!"),G("EN")},className:"translate-button en-button",style:{cursor:"pointer",pointerEvents:"auto"},children:[c.jsx("svg",{className:"button-icon",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:c.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129"})}),"Translate to EN"]})]})]})})]})};function H(){try{return!!chrome.runtime.id}catch(t){return console.error("Extension context invalidated:",t),!1}}let R=null,I=!1,N=!1;const lt=500;function Yt(t,o,e){if(!H()){console.warn("Cannot create translate icons: extension context invalidated");return}T(),C(),console.log("Creating translate icons");const n=V();if(!n){console.log("No valid position for icons");return}const i=window.PRIMARY_LANG||"BN",r=document.createElement("div");r.innerText=i,r.setAttribute("data-translate-icon","primary"),r.style.position="absolute",r.style.top=`${n.top}px`,r.style.left=`${n.left}px`,r.style.width="32px",r.style.height="32px",r.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",r.style.border="2px solid rgba(255, 255, 255, 0.3)",r.style.borderRadius="50%",r.style.boxShadow="0 4px 20px rgba(102, 126, 234, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",r.style.cursor="pointer",r.style.zIndex=2147483647,r.style.display="flex",r.style.alignItems="center",r.style.justifyContent="center",r.style.fontSize="11px",r.style.fontWeight="700",r.style.color="#ffffff",r.style.fontFamily="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",r.style.textShadow="0 1px 2px rgba(0, 0, 0, 0.3)",r.style.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",r.style.backdropFilter="blur(10px)",r.style.userSelect="none";const s=document.createElement("div");s.innerText="EN",s.setAttribute("data-translate-icon","en"),s.style.position="absolute",s.style.top=`${n.top}px`,s.style.left=`${n.left+40}px`,s.style.width="32px",s.style.height="32px",s.style.background="linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",s.style.border="2px solid rgba(255, 255, 255, 0.3)",s.style.borderRadius="50%",s.style.boxShadow="0 4px 20px rgba(240, 147, 251, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",s.style.cursor="pointer",s.style.zIndex=2147483647,s.style.display="flex",s.style.alignItems="center",s.style.justifyContent="center",s.style.fontSize="11px",s.style.fontWeight="700",s.style.color="#ffffff",s.style.fontFamily="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",s.style.textShadow="0 1px 2px rgba(0, 0, 0, 0.3)",s.style.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",s.style.backdropFilter="blur(10px)",s.style.userSelect="none",r.addEventListener("mouseenter",()=>{r.style.transform="scale(1.15) translateY(-2px)",r.style.boxShadow="0 8px 30px rgba(102, 126, 234, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)",r.style.background="linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%)"}),r.addEventListener("mouseleave",()=>{r.style.transform="scale(1) translateY(0px)",r.style.boxShadow="0 4px 20px rgba(102, 126, 234, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",r.style.background="linear-gradient(135deg, #667eea 0%, #764ba2 100%)",clearTimeout(R),console.log("Mouse left primary icon, cleared timer")}),s.addEventListener("mouseenter",()=>{s.style.transform="scale(1.15) translateY(-2px)",s.style.boxShadow="0 8px 30px rgba(240, 147, 251, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)",s.style.background="linear-gradient(135deg, #ec4899 0%, #f43f5e 100%)"}),s.addEventListener("mouseleave",()=>{s.style.transform="scale(1) translateY(0px)",s.style.boxShadow="0 4px 20px rgba(240, 147, 251, 0.4), 0 2px 8px rgba(0, 0, 0, 0.15)",s.style.background="linear-gradient(135deg, #f093fb 0%, #f5576c 100%)",clearTimeout(R),console.log("Mouse left EN icon, cleared timer")}),r.addEventListener("mousedown",()=>{r.style.transform="scale(1.05) translateY(0px)",r.style.boxShadow="0 2px 10px rgba(102, 126, 234, 0.5), 0 1px 4px rgba(0, 0, 0, 0.2)"}),r.addEventListener("mouseup",()=>{r.style.transform="scale(1.15) translateY(-2px)",r.style.boxShadow="0 8px 30px rgba(102, 126, 234, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)"}),s.addEventListener("mousedown",()=>{s.style.transform="scale(1.05) translateY(0px)",s.style.boxShadow="0 2px 10px rgba(240, 147, 251, 0.5), 0 1px 4px rgba(0, 0, 0, 0.2)"}),s.addEventListener("mouseup",()=>{s.style.transform="scale(1.15) translateY(-2px)",s.style.boxShadow="0 8px 30px rgba(240, 147, 251, 0.6), 0 4px 15px rgba(0, 0, 0, 0.2)"}),r.addEventListener("pointerdown",a=>{a.preventDefault(),a.stopPropagation(),N=!0,I=!1,console.log("Pointer down on primary icon, starting long press timer"),R=setTimeout(()=>{if(I=!0,console.log("Long press detected on primary icon"),console.log("Current selection info:",e),!e||!e.text){console.log("No valid selection info, aborting long press"),N=!1;return}console.log("Creating translation box for:",e.text,"in language:",i),o(e.text,i),T(),console.log("Icons removed after long press"),N=!1},lt)}),s.addEventListener("pointerdown",a=>{a.preventDefault(),a.stopPropagation(),N=!0,I=!1,console.log("Pointer down on EN icon, starting long press timer"),R=setTimeout(()=>{if(I=!0,console.log("Long press detected on EN icon"),console.log("Current selection info:",e),!e||!e.text){console.log("No valid selection info, aborting long press"),N=!1;return}console.log("Creating translation box for:",e.text,"in language: EN"),o(e.text,"EN"),T(),console.log("Icons removed after long press"),N=!1},lt)}),r.addEventListener("pointerup",async a=>{a.preventDefault(),a.stopPropagation(),clearTimeout(R),I?console.log("Pointer up after long press on primary icon, keeping box open"):(console.log("Regular click on primary icon"),e&&e.text?await t(i,e):console.log("No valid selection info for primary icon click")),N=!1}),s.addEventListener("pointerup",async a=>{a.preventDefault(),a.stopPropagation(),clearTimeout(R),I?console.log("Pointer up after long press on EN icon, keeping box open"):(console.log("Regular click on EN icon"),e&&e.text?await t("EN",e):console.log("No valid selection info for EN icon click")),N=!1}),r.addEventListener("contextmenu",a=>a.preventDefault()),s.addEventListener("contextmenu",a=>a.preventDefault()),document.body.appendChild(r),document.body.appendChild(s)}function T(){console.log("removeTranslateIcon called"),document.querySelectorAll("[data-translate-icon]").forEach(o=>{o.parentNode&&(console.log(`Removing ${o.getAttribute("data-translate-icon")} icon`),o.parentNode.removeChild(o))})}function K(){const t=document.querySelector('[data-translate-icon="primary"]'),o=document.querySelector('[data-translate-icon="en"]');return{iconElementBN:t,iconElementEN:o}}function ht(){return console.log("Checking long press state:",N),N}function bt(){console.log("Resetting long press state"),N=!1,I=!1,R&&(clearTimeout(R),R=null)}let B="",Y=null;function $t(t,o,e){if(ht()){console.log("Skipping selection event during long press processing");return}if(!H()){console.warn("Cannot handle selection event: extension context invalidated");return}const n=gt(),i=U();if(n&&n.text&&i){const a=window.getSelection().getRangeAt(0).commonAncestorContainer;if(i.contains(a.nodeType===1?a:a.parentElement)){console.log("Selection inside translation box, ignoring"),o();return}}if(n&&n.text){const r=B;B=n.text,Y=n,console.log("Selection detected:",n.text,"Previous text was:",r,"Current state - lastSelectedText:",B,"currentSelectionInfo:",!!Y),t()}else(!n||!n.text)&&(console.log("No valid selection, removing icons and clearing state"),B="",Y=null,o(),e())}function A(){return Y}function Ft(){console.log("Initializing selection state"),B="",Y=null,bt()}let p=null,L=null,$=null,F=null,O=null,z=null;function ct(t,o,e){console.log("Recreating box with forced top-right positioning"),t&&t.parentNode&&t.parentNode.removeChild(t);const n=document.createElement("div");n.id="translation-box-container";const i={position:"fixed",top:"20px",right:"20px",left:"auto",width:"400px",height:"600px",zIndex:"2147483647",boxSizing:"border-box",pointerEvents:"auto",visibility:"visible",opacity:"1",transform:"none",filter:"none",backdropFilter:"none",margin:"0",padding:"0",border:"none",outline:"none"};Object.assign(n.style,i),n.style.setProperty("position","fixed","important"),n.style.setProperty("top","20px","important"),n.style.setProperty("right","20px","important"),n.style.setProperty("left","auto","important"),n.style.setProperty("z-index","2147483647","important"),document.body.appendChild(n),p=n,L=dt.createRoot(n),L.render(c.jsx(ft,{selectedText:o,targetLang:e,onClose:()=>{console.log("Close button clicked"),M()}})),console.log("Box recreated with forced top-right positioning")}function X(t){if(!t)return;t.parentNode&&t.parentNode!==document.body&&document.body.appendChild(t);const o={position:"fixed",zIndex:"2147483647",elevation:"2147483647",layer:"2147483647",isolation:"isolate",contain:"layout style paint",willChange:"transform",transform:"translateZ(0)",overflow:"visible",clip:"auto",clipPath:"none"};Object.assign(t.style,o),t.style.setProperty("z-index","2147483647","important"),t.style.setProperty("position","fixed","important"),t.style.setProperty("isolation","isolate","important"),t.style.setProperty("contain","layout style paint","important"),t.style.setProperty("will-change","transform","important"),t.style.setProperty("transform","translateZ(0)","important"),console.log("Forced maximum z-index applied"),setTimeout(()=>{const e=window.getComputedStyle(t);console.log("Computed z-index:",e.zIndex),console.log("Computed position:",e.position)},10)}function j(t){if(!t)return;const o=window.innerWidth,e=window.innerHeight,n=20,i={position:"fixed",top:`${n}px`,right:`${n}px`,left:"auto",width:"400px",height:"600px",zIndex:"2147483647",visibility:"visible",opacity:"1",pointerEvents:"auto",transform:"none",boxSizing:"border-box"};Object.assign(t.style,i),console.log("Forced viewport-relative top-right positioning applied"),setTimeout(()=>{const r=t.getBoundingClientRect();console.log("Position after force top-right:",{rect:{top:r.top,left:r.left,right:r.right,bottom:r.bottom},expected:{top:n,right:o-n},viewport:{width:o,height:e}})},10)}function W(t){if(!t)return;const o=t.getBoundingClientRect(),e=window.innerWidth,n=window.innerHeight;window.scrollX||document.documentElement.scrollLeft,window.scrollY||document.documentElement.scrollTop;let i=!1,r={};(o.width<=0||o.height<=0)&&(console.log("Box has invalid dimensions, repositioning"),i=!0,r={width:"400px",height:"600px"}),(o.left<0||o.left>e)&&(r.right="20px",r.left="auto",i=!0),(o.right>e||o.right<0)&&(r.right="20px",r.left="auto",i=!0),(o.top<0||o.top>n)&&(r.top="20px",i=!0),(o.bottom>n||o.bottom<0)&&(r.top="20px",i=!0),o.width<200&&(r.width="400px",i=!0),o.height<300&&(r.height="600px",i=!0);const s={visibility:"visible",opacity:"1",display:"block",zIndex:"2147483647",position:"fixed",pointerEvents:"auto",transform:"none",filter:"none",backdropFilter:"none"};Object.assign(t.style,s);let a=t.parentElement,l=0;const m=10;for(;a&&a!==document.body&&l<m;){const d=window.getComputedStyle(a);d.overflow==="hidden"&&(a.style.overflow="visible"),d.visibility==="hidden"&&(a.style.visibility="visible"),d.display==="none"&&(a.style.display="block"),d.opacity==="0"&&(a.style.opacity="1"),d.transform&&d.transform!=="none"&&(a.style.transform="none"),d.filter&&d.filter!=="none"&&(a.style.filter="none"),a=a.parentElement,l++}if(i){console.log("Box needs repositioning:",r),Object.assign(t.style,r),t.offsetHeight;const d=t.getBoundingClientRect();if(d.left<0||d.right>e||d.top<0||d.bottom>n){console.log("Box still outside viewport after repositioning, using fallback position");const h={top:"20px",left:"auto",right:"20px",width:"400px",height:"600px",zIndex:"2147483647"};Object.assign(t.style,h)}}const g=t.getBoundingClientRect();g.width>0&&g.height>0&&g.left>=0&&g.right<=e+1&&g.top>=0&&g.bottom<=n||(console.warn("Box visibility validation failed, forcing top-right position"),console.log("Final rect:",g),console.log("Viewport:",{width:e,height:n}),j(t))}function Z(t){if(!t)return;const o=t.querySelectorAll(".translate-button, .bn-button, .en-button"),e=t.querySelectorAll(".button-icon"),n=t.querySelector(".button-container"),i=t.querySelector(".input-container"),r=t.querySelector(".input-form"),s=t.querySelector(".chat-input");if(o.forEach(a=>{const l={padding:"12px",borderRadius:"12px",fontWeight:"600",fontSize:"14px",cursor:"pointer",border:"none",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px",minWidth:"120px",minHeight:"44px",width:"auto",height:"auto",boxSizing:"border-box",margin:"0",lineHeight:"1.5",textDecoration:"none",textTransform:"none",letterSpacing:"normal",wordSpacing:"normal",whiteSpace:"nowrap",verticalAlign:"middle",fontFamily:"inherit",fontStyle:"normal",fontVariant:"normal",transform:"none",position:"relative",overflow:"visible",color:"white"};Object.assign(a.style,l)}),e.forEach(a=>{const l={width:"16px",height:"16px",minWidth:"16px",minHeight:"16px",maxWidth:"16px",maxHeight:"16px",display:"inline-block",verticalAlign:"middle",transform:"none"};Object.assign(a.style,l)}),n){const a={display:"grid",gridTemplateColumns:"1fr 1fr",gap:"12px",width:"100%",minHeight:"44px",margin:"0",padding:"0",boxSizing:"border-box"};Object.assign(n.style,a)}if(i){const a={display:"flex",flexDirection:"column",gap:"16px",width:"100%",margin:"0",padding:"0",boxSizing:"border-box"};Object.assign(i.style,a)}if(r){const a={padding:"16px",borderTop:"1px solid #e2e8f0",background:"rgba(255, 255, 255, 0.8)",width:"100%",boxSizing:"border-box",margin:"0",flexShrink:"0"};Object.assign(r.style,a)}if(s){const a={width:"100%",padding:"12px 16px",fontSize:"14px",border:"1px solid #d1d5db",borderRadius:"12px",background:"rgba(255, 255, 255, 0.9)",color:"#374151",fontFamily:"inherit",lineHeight:"1.5",boxSizing:"border-box",outline:"none",minHeight:"44px",height:"auto",margin:"0",textDecoration:"none",textTransform:"none",letterSpacing:"normal",wordSpacing:"normal",whiteSpace:"normal",verticalAlign:"middle",fontStyle:"normal",fontVariant:"normal",transform:"none",backgroundColor:"rgba(255, 255, 255, 0.9)",backgroundImage:"none"};Object.assign(s.style,a)}console.log("Forced button sizing applied")}function Ot(t,o){if(console.log("createTranslationBox called with:",t,o),!H()){console.warn("Cannot create translation box: extension context invalidated");return}if(p){console.log("Translation box already open, appending text:",t,"targetLang:",o);const l=new CustomEvent("appendTranslation",{detail:{text:t,targetLang:o}});p.dispatchEvent(l);return}console.log("Creating new translation box with text:",t,"targetLang:",o);const e=D();if(!e){console.log("No valid position for translation box");return}console.log("Creating box with position:",e);const n=document.createElement("div");n.id="translation-box-container";const i={position:"fixed",top:"20px",right:"20px",left:"auto",width:"400px",height:"600px",zIndex:"2147483647",boxSizing:"border-box",pointerEvents:"auto",visibility:"visible",opacity:"1",transform:"none",filter:"none",backdropFilter:"none",margin:"0",padding:"0",border:"none",outline:"none"};Object.assign(n.style,i),n.style.setProperty("position","fixed","important"),n.style.setProperty("top","20px","important"),n.style.setProperty("right","20px","important"),n.style.setProperty("left","auto","important"),n.style.setProperty("z-index","2147483647","important"),console.log("Box styles applied:",{position:n.style.position,top:n.style.top,right:n.style.right,left:n.style.left,width:n.style.width,height:n.style.height,zIndex:n.style.zIndex}),document.body.appendChild(n),p=n,X(n),j(n),setTimeout(()=>{const l=n.getBoundingClientRect();console.log("Box position after append:",{rect:{top:l.top,left:l.left,right:l.right,bottom:l.bottom,width:l.width,height:l.height},viewport:{width:window.innerWidth,height:window.innerHeight},styles:{top:n.style.top,right:n.style.right,left:n.style.left,position:n.style.position}}),l.left<window.innerWidth-450&&(console.log("Box not in right position, forcing again"),j(n),setTimeout(()=>{n.getBoundingClientRect().left<window.innerWidth-450&&(console.log("Box still not in top-right after force, recreating"),ct(n,t,o))},1e3))},50),setTimeout(()=>{W(n),Z(n),j(n)},100),$=()=>{if(p&&p.parentNode){console.log("Window resized, updating translation box position");const l=D();l?(console.log(`Updating box size on resize: width=${l.width}, height=${l.height}`),p.style.width=`${l.width}px`,p.style.height=`${l.height}px`,p.style.top=`${l.top}px`,p.style.right=`${l.right}px`,p.style.left="auto",p.style.transform="none",setTimeout(()=>{W(p),Z(p)},50)):(console.log("No valid position for box on resize, removing box"),M())}},F=()=>{p&&p.parentNode&&j(p)},window.addEventListener("resize",$),window.addEventListener("scroll",F),O=new MutationObserver(l=>{if(p&&p.parentNode){let m=!1;if(l.forEach(g=>{if(g.type==="childList"&&g.addedNodes.forEach(x=>{if(x.nodeType===1){const d=window.getComputedStyle(x);(d.position==="fixed"||d.position==="sticky")&&(m=!0);const h=x.tagName?.toLowerCase(),b=x.className?.toLowerCase()||"";(h==="header"||h==="nav"||b.includes("header")||b.includes("navbar")||b.includes("sidebar")||b.includes("menu"))&&(m=!0)}}),g.type==="attributes"&&g.attributeName==="style"){const x=g.target;if(x&&x!==p){const d=window.getComputedStyle(x);(d.position==="fixed"||d.position==="sticky")&&(m=!0)}}if(g.type==="attributes"&&g.attributeName==="class"){const x=g.target;if(x&&x!==p){const d=x.className?.toLowerCase()||"";(d.includes("header")||d.includes("navbar")||d.includes("sidebar")||d.includes("menu")||d.includes("fixed")||d.includes("sticky"))&&(m=!0)}}}),m){console.log("Website layout changed, repositioning translation box");const g=D();g&&(p.style.top=`${g.top}px`,p.style.width=`${g.width}px`,p.style.height=`${g.height}px`,p.style.right=`${g.right}px`,p.style.left="auto",p.style.transform="none"),setTimeout(()=>{W(p),Z(p)},100)}}}),O.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["style","class"]});const r=ut();(r.isProblematicWebsite||r.hasAggressiveCSS)&&(z=setInterval(()=>{p&&p.parentNode?(W(p),X(p),j(p)):(clearInterval(z),z=null)},2e3));const s=setInterval(()=>{p&&p.parentNode?p.getBoundingClientRect().left<window.innerWidth-450&&(console.log("Box moved from top-right, repositioning"),X(p),j(p),setTimeout(()=>{p.getBoundingClientRect().left<window.innerWidth-450&&(console.log("Box still not in top-right, recreating"),ct(p,t,o))},2e3)):clearInterval(s)},1e3);n._positionCheckInterval=s;const a=l=>{const{iconElementBN:m,iconElementEN:g}=K(),x=A();if(p&&p.contains(l.target)){console.log("Click inside translation box, ignoring");return}if(m&&m.contains(l.target)||g&&g.contains(l.target)){console.log("Click on translate icon, ignoring");return}if(x&&x.range){const h=x.range.commonAncestorContainer,b=h.nodeType===1?h:h.parentElement;if(b&&b.contains(l.target)){console.log("Click within selected text, ignoring");return}}console.log("Outside click detected, closing translation box"),M()};document.addEventListener("click",a),n._outsideClickHandler=a,L=dt.createRoot(n),L.render(c.jsx(ft,{selectedText:t,targetLang:o,onClose:()=>{console.log("Close button clicked"),M()}}))}function M(){p&&p.parentNode&&(console.log("Removing translation box"),p._outsideClickHandler&&(document.removeEventListener("click",p._outsideClickHandler),p._outsideClickHandler=null),p._positionCheckInterval&&(clearInterval(p._positionCheckInterval),p._positionCheckInterval=null),$&&(window.removeEventListener("resize",$),$=null),F&&(window.removeEventListener("scroll",F),F=null),O&&(O.disconnect(),O=null),z&&(clearInterval(z),z=null),L&&(L.unmount(),L=null),p.parentNode.removeChild(p),p=null)}function U(){return p}function J(t,o){if(!H())return console.warn("Cannot replace text: extension context invalidated"),!1;if(console.log("Replacing text in UI:",t,"selectionInfo:",o),!o||!t)return console.warn("Invalid selectionInfo or text, aborting replace"),!1;try{if(o.type==="input"||o.type==="translationBoxInput"||o.type==="inputLikeDiv"){const e=o.element,n=o.start,i=o.end;console.log("Input replace: current value=",e.value),console.log("Replacing from position",n,"to",i,"with:",t);const r=e.value.substring(0,n)+t+e.value.substring(i);console.log("Setting new input value:",r),e.value=r;const s=n+t.length;if(e.setSelectionRange(s,s),o.type==="translationBoxInput"){console.log("Handling translation box input replacement"),console.log("Original value:",e.value),console.log("New value:",r),console.log("Selection start:",n,"end:",i),window.lastTranslationSelection={start:n,end:i,newText:t,newValue:r};const a=new CustomEvent("translationBoxInputChange",{detail:{element:e,start:n,end:i,newText:t,newValue:r}});e.dispatchEvent(a);const l=new Event("input",{bubbles:!0});e.dispatchEvent(l),console.log("Events dispatched for translation box input")}else if(o.type==="inputLikeDiv"){console.log("Handling input-like div replacement");const a=o.selection,l=o.range;a.removeAllRanges(),a.addRange(l),l.deleteContents();const m=document.createTextNode(t);l.insertNode(m),l.setStartAfter(m),l.setEndAfter(m),a.removeAllRanges(),a.addRange(l);const g=new Event("input",{bubbles:!0});e.dispatchEvent(g),console.log("Input-like div replacement successful")}else{const a=new Event("input",{bubbles:!0});e.dispatchEvent(a)}return console.log("Input replace successful"),!0}else if(o.type==="contenteditable"){const e=o.editableElement;console.log("ContentEditable replace: currentHTML=",e.innerHTML);const n=window.getSelection();if(n.removeAllRanges(),n.addRange(o.range),!n.rangeCount)return console.warn("No valid selection range, attempting fallback"),_(t,o);const i=n.getRangeAt(0),r=i.commonAncestorContainer.nodeType===1?i.commonAncestorContainer:i.commonAncestorContainer.parentElement,s=window.getComputedStyle(r);i.deleteContents();const a=document.createTextNode(t),l=document.createElement("span");return l.style.fontFamily='"Noto Sans Bengali", "Kalpurush", Arial, sans-serif',l.style.fontSize=s.fontSize,l.style.fontWeight=s.fontWeight,l.style.color=s.color,l.style.whiteSpace="pre-wrap",l.appendChild(a),i.insertNode(l),e.normalize(),i.setStartAfter(l),i.setEndAfter(l),n.removeAllRanges(),n.addRange(i),[new Event("input",{bubbles:!0,cancelable:!0}),new Event("change",{bubbles:!0,cancelable:!0}),new InputEvent("input",{bubbles:!0,cancelable:!0,data:t,inputType:"insertText"}),new Event("keyup",{bubbles:!0,cancelable:!0})].forEach(g=>e.dispatchEvent(g)),e.focus(),console.log("ContentEditable replace successful"),!0}else{const e=window.getSelection();if(e.removeAllRanges(),e.addRange(o.range),!e.rangeCount)return console.warn("No valid selection range, attempting fallback"),_(t,o);const n=e.getRangeAt(0);console.log("Regular text replacement - range:",{startContainer:n.startContainer,startOffset:n.startOffset,endContainer:n.endContainer,endOffset:n.endOffset,commonAncestorContainer:n.commonAncestorContainer});const i=n.commonAncestorContainer.nodeType===1?n.commonAncestorContainer:n.commonAncestorContainer.parentElement;console.log("Parent element:",i);const r=i.textContent,s=e.toString();console.log("Original text:",r),console.log("Selected text:",s);const a=r.indexOf(s);if(a!==-1){const l=r.substring(0,a),m=r.substring(a+s.length);console.log("Before text:",l),console.log("After text:",m);const g=l+t+m;console.log("New text content:",g),i.textContent=g;const x=a+t.length,d=i.firstChild;if(d&&d.nodeType===Node.TEXT_NODE){const h=document.createRange();h.setStart(d,x),h.setEnd(d,x),e.removeAllRanges(),e.addRange(h)}return console.log("Regular replace successful"),!0}else return console.warn("Selected text not found in parent element, using fallback"),_(t,o)}}catch(e){return console.error("Error replacing text:",e),_(t,o)}}function _(t,o){console.log("Attempting fallback replace with:",t);try{if(document.queryCommandSupported&&document.queryCommandSupported("insertText")){console.log("Using insertText fallback");const e=window.getSelection();return e.removeAllRanges(),e.addRange(o.range),document.execCommand("insertText",!1,t),console.log("insertText fallback successful"),!0}else return navigator.clipboard&&o.type==="contenteditable"?(console.log("Using clipboard fallback for contenteditable"),navigator.clipboard.writeText(t).then(()=>{const e=window.getSelection();e.removeAllRanges(),e.addRange(o.range),document.execCommand("paste"),console.log("Clipboard fallback successful")}),!0):(console.warn("No fallback available for text replace"),!1)}catch(e){return console.error("Fallback replace failed:",e),!1}}async function yt(t,o,e){if(!H()){console.warn("Cannot handle translation: extension context invalidated"),C();return}const n=V();Lt(n);try{const i=gt();if(!i||i.text!==o.text){console.warn("Selection changed or invalid, aborting translation"),C(),e(),bt();return}o=i;try{const r=`${t}=true: ${o.text}`,s=await xt(r,t,!1);J(s,o)}catch(r){console.error(`API error during ${t} translation:`,r);let s=`Translation failed: ${r.message}`;r.message.includes("402")?window.AI_PROVIDER==="openrouter"?s="Translation failed: Insufficient OpenRouter credits. Please visit https://openrouter.ai/credits to add credits or use a different model.":window.AI_PROVIDER==="deepseek"&&(s="Translation failed: Insufficient DeepSeek account balance. Please visit https://platform.deepseek.com/ to top up your account or contact support at service@deepseek.com."):r.message.includes("429")&&(s="Translation failed: Rate limit exceeded. Please try again later or switch to a different model."),J(s,o),C();return}}catch(i){if(console.error(`Unexpected error during ${t} translation:`,i),i.message.includes("Extension context invalidated")){console.warn("Context invalidated, aborting translation"),C();return}J(`Translation failed: ${i.message}`,o)}finally{C()}}let q=!1;window.PRIMARY_LANG="BN";window.PRIMARY_KEY="M";window.SECONDARY_KEY="E";function wt(){return new Promise(t=>{chrome.storage.sync.get(["primaryLang","primaryKey","secondaryKey"],o=>{window.PRIMARY_LANG=o.primaryLang||"BN",window.PRIMARY_KEY=o.primaryKey||"M",window.SECONDARY_KEY=o.secondaryKey||"E",console.log("Loaded settings:",window.PRIMARY_LANG,window.PRIMARY_KEY,window.SECONDARY_KEY),t()})})}function ot(){const t=A();return Yt(async o=>{const e=A();e&&await yt(o,e,ot)},(o,e)=>Ot(o,e),t)}function Q(){$t(ot,T,C)}async function pt(t){const o=A();o&&await yt(t,o,ot)}async function et(){if(!q)try{if(console.log("Initializing Translix extension..."),document.readyState==="loading"){console.log("Page still loading, waiting for DOMContentLoaded");return}await wt(),Ft(),console.log("UpdateModal will be initialized on demand..."),T(),C();const t=document.createElement("style");t.id="translix-extension-styles",t.textContent=`
      /* Translation Box - Pure Raw CSS (No Tailwind) */
      #translation-box-container {
        position: fixed !important; /* Always viewport-relative */
        top: 20px !important; /* Always 20px from top of viewport */
        right: 20px !important; /* Always 20px from right of viewport */
        left: auto !important;
        width: 400px !important;
        height: 600px !important;
        z-index: 2147483647 !important; /* Maximum z-index to be above everything */
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
        font-size: 14px !important;
        line-height: 1.5 !important;
        /* Force isolation from website CSS */
        all: initial !important;
        box-sizing: border-box !important;
        /* Ensure proper display */
        display: block !important;
        visibility: visible !important;
        opacity: 1 !important;
        pointer-events: auto !important;
        /* Prevent website CSS interference */
        transform: none !important;
        filter: none !important;
        backdrop-filter: none !important;
        /* Force proper colors */
        color: #1e293b !important;
        background: transparent !important;
        background-color: transparent !important;
        background-image: none !important;
        /* Force positioning - override any website CSS */
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        outline: none !important;
        float: none !important;
        clear: none !important;
        /* Ensure it's not affected by parent elements */
        position: fixed !important;
        top: 20px !important;
        right: 20px !important;
        left: auto !important;
        bottom: auto !important;
        /* Force stacking context and ensure it's above everything */
        isolation: isolate !important;
        contain: layout style paint !important;
        will-change: transform !important;
        transform: translateZ(0) !important;
        /* Additional properties to ensure it's above everything */
        elevation: 2147483647 !important;
        layer: 2147483647 !important;
        /* Force it to be the highest element */
        position: fixed !important;
        z-index: 2147483647 !important;
        /* Ensure it's not clipped by parent elements */
        overflow: visible !important;
        clip: auto !important;
        clip-path: none !important;
        /* Force rendering above everything */
        render-layer: 2147483647 !important;
      }

      /* Force our box to be above any website elements */
      body > #translation-box-container {
        z-index: 2147483647 !important;
        position: fixed !important;
        top: 20px !important;
        right: 20px !important;
        left: auto !important;
        bottom: auto !important;
        /* Ensure it's the highest element */
        isolation: isolate !important;
        contain: layout style paint !important;
        will-change: transform !important;
        transform: translateZ(0) !important;
        /* Force rendering above everything */
        elevation: 2147483647 !important;
        layer: 2147483647 !important;
        render-layer: 2147483647 !important;
      }

      #translation-box-container * {
        /* Reset only essential properties for child elements */
        box-sizing: border-box !important;
        font-family: inherit !important;
        /* Prevent website CSS interference */
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        outline: none !important;
        text-decoration: none !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        white-space: normal !important;
        vertical-align: baseline !important;
        /* Ensure proper font rendering */
        font-style: normal !important;
        font-variant: normal !important;
        font-weight: normal !important;
        /* Prevent any transforms */
        transform: none !important;
        /* Force proper colors */
        color: inherit !important;
        background: transparent !important;
        background-color: transparent !important;
        background-image: none !important;
      }

      /* Main Container */
      #translation-box-container .translation-box-main {
        width: 400px !important;
        height: 600px !important;
        background: #ffffff !important;
        border-radius: 16px !important;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25) !important;
        border: 1px solid #e2e8f0 !important;
        overflow: hidden !important;
        display: flex !important;
        flex-direction: column !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
        font-size: 14px !important;
        line-height: 1.5 !important;
        position: relative !important;
        /* Force proper sizing */
        min-width: 400px !important;
        min-height: 600px !important;
        max-width: 400px !important;
        max-height: 600px !important;
      }

      /* Header */
      #translation-box-container .translation-box-header {
        background: linear-gradient(to right, #2563eb, #7c3aed, #4f46e5) !important;
        color: white !important;
        padding: 12px !important;
        flex-shrink: 0 !important;
        border-bottom: none !important;
        /* Force proper sizing */
        min-height: 48px !important;
        height: 70px !important;
      }

      #translation-box-container .header-content {
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
        width: 100% !important;
        height: 100% !important;
      }

      #translation-box-container .header-left {
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
      }

      #translation-box-container .logo-container {
        width: 24px !important;
        height: 24px !important;
        background: white !important;
        border-radius: 8px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
        flex-shrink: 0 !important;
      }

      #translation-box-container .logo-icon {
        width: 16px !important;
        height: 16px !important;
        fill: white !important;
      }

      #translation-box-container .header-text {
        display: flex !important;
        flex-direction: column !important;
        font-size: 18px !important;
      }

      #translation-box-container .app-title {
        font-weight: bold !important;
        font-size: 14px !important;
        margin: 0 !important;
        color: white !important;
      }

      #translation-box-container .app-subtitle {
        font-size: 12px !important;
        color: #bfdbfe !important;
        margin: 0 !important;
      }

      #translation-box-container .close-button {
        padding: 6px !important;
        background: none !important;
        border: none !important;
        color: white !important;
        border-radius: 8px !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        min-width: 24px !important;
        min-height: 24px !important;
        flex-shrink: 0 !important;
      }

      #translation-box-container .close-button:hover {
        background: rgba(255, 255, 255, 0.2) !important;
        transform: scale(1.05) !important;
      }

      #translation-box-container .close-button:disabled {
        opacity: 0.5 !important;
        cursor: not-allowed !important;
      }

      #translation-box-container .close-icon {
        width: 16px !important;
        height: 16px !important;
        fill: white !important;
      }

      /* Messages Container */
      #translation-box-container .messages-container {
        flex: 1 !important;
        overflow-y: auto !important;
        padding: 12px !important;
        background: #f8fafc !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 12px !important;
        min-height: 0 !important;
        /* Force proper sizing */
        height: calc(600px - 48px - 120px) !important;
      }

      /* Input Form - Fixed Bottom Design */
      #translation-box-container .input-form {
        padding: 16px !important;
        border-top: 1px solid #e2e8f0 !important;
        background: #ffffff !important;
        flex-shrink: 0 !important;
        min-height: 120px !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: space-between !important;
        /* Force proper sizing */
        width: 100% !important;
        box-sizing: border-box !important;
      }

      #translation-box-container .input-container {
        display: flex !important;
        flex-direction: column !important;
        gap: 16px !important;
        width: 100% !important;
        height: 100% !important;
      }

      #translation-box-container .chat-input {
        width: 100% !important;
        padding: 12px 16px !important;
        font-size: 14px !important;
        border: 1px solid #d1d5db !important;
        border-radius: 12px !important;
        background: #ffffff !important;
        color: #374151 !important;
        font-family: inherit !important;
        line-height: 1.5 !important;
        box-sizing: border-box !important;
        outline: none !important;
        transition: border-color 0.2s ease-in-out !important;
        min-height: 44px !important;
        height: 44px !important;
        resize: none !important;
        /* Force proper sizing */
        margin: 0 !important;
        text-decoration: none !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        white-space: normal !important;
        vertical-align: middle !important;
        font-style: normal !important;
        font-variant: normal !important;
        transform: none !important;
        background-color: #ffffff !important;
        background-image: none !important;
      }

      #translation-box-container .chat-input:focus {
        border-color: #3b82f6 !important;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
      }

      #translation-box-container .chat-input:disabled {
        background: #f1f5f9 !important;
        background-color: #f1f5f9 !important;
        cursor: not-allowed !important;
      }

      #translation-box-container .button-container {
        display: grid !important;
        grid-template-columns: 1fr 1fr !important;
        gap: 12px !important;
        width: 100% !important;
        min-height: 44px !important;
        height: 44px !important;
        /* Force proper sizing */
        margin: 0 !important;
        padding: 0 !important;
        box-sizing: border-box !important;
        margin-top: 20px !important;
      }

      #translation-box-container .translate-button {
        padding: 12px !important;
        border-radius: 12px !important;
        font-weight: 600 !important;
        font-size: 14px !important;
        transition: all 0.2s ease !important;
        cursor: pointer !important;
        border: none !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        gap: 8px !important;
        min-width: 140px !important;
        min-height: 44px !important;
        height: 44px !important;
        white-space: nowrap !important;
        text-decoration: none !important;
        color: white !important;
        /* Force proper sizing */
        box-sizing: border-box !important;
        margin: 0 !important;
        line-height: 1.5 !important;
        text-transform: none !important;
        letter-spacing: normal !important;
        word-spacing: normal !important;
        vertical-align: middle !important;
        font-family: inherit !important;
        font-style: normal !important;
        font-variant: normal !important;
        transform: none !important;
        position: relative !important;
        overflow: visible !important;
        background: initial !important;
        background-color: initial !important;
        background-image: initial !important;
      }

      #translation-box-container .translate-button:hover {
        transform: scale(1.02) !important;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .translate-button:disabled {
        opacity: 0.5 !important;
        cursor: not-allowed !important;
        transform: none !important;
      }

      #translation-box-container .bn-button {
        background: linear-gradient(to right, #10b981, #059669) !important;
        background-image: linear-gradient(to right, #10b981, #059669) !important;
        color: white !important;
      }

      #translation-box-container .bn-button:hover:not(:disabled) {
        background: linear-gradient(to right, #059669, #047857) !important;
        background-image: linear-gradient(to right, #059669, #047857) !important;
      }

      #translation-box-container .en-button {
        background: linear-gradient(to right, #3b82f6, #1d4ed8) !important;
        background-image: linear-gradient(to right, #3b82f6, #1d4ed8) !important;
        color: white !important;
      }

      #translation-box-container .en-button:hover:not(:disabled) {
        background: linear-gradient(to right, #1d4ed8, #1e40af) !important;
        background-image: linear-gradient(to right, #1d4ed8, #1e40af) !important;
      }

      #translation-box-container .button-icon {
        width: 16px !important;
        height: 16px !important;
        fill: currentColor !important;
        flex-shrink: 0 !important;
        /* Force icon sizing */
        min-width: 16px !important;
        min-height: 16px !important;
        max-width: 16px !important;
        max-height: 16px !important;
        display: inline-block !important;
        vertical-align: middle !important;
        transform: none !important;
      }

      /* Messages */
      #translation-box-container .message-wrapper {
        display: flex !important;
        width: 100% !important;
      }

      #translation-box-container .user-wrapper {
        justify-content: flex-end !important;
      }

      #translation-box-container .ai-wrapper {
        justify-content: flex-start !important;
      }

      #translation-box-container .message-bubble {
        max-width: 280px !important;
        padding: 12px !important;
        border-radius: 12px !important;
        font-size: 12px !important;
        position: relative !important;
        display: flex !important;
        flex-direction: column !important;
        word-wrap: break-word !important;
      }

      #translation-box-container .user-message {
        background: linear-gradient(to right, #2563eb, #7c3aed) !important;
        color: white !important;
        border-bottom-right-radius: 4px !important;
      }

      #translation-box-container .ai-message {
        background: #ffffff !important;
        color: #1e293b !important;
        border: 1px solid #e2e8f0 !important;
        border-bottom-left-radius: 4px !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .error-message {
        background: #fef2f2 !important;
        border: 1px solid #fecaca !important;
        color: #991b1b !important;
        border-radius: 8px !important;
        box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .message-content {
        display: flex !important;
        align-items: flex-start !important;
        gap: 8px !important;
        margin-bottom: 8px !important;
      }

      #translation-box-container .message-icon {
        width: 20px !important;
        height: 20px !important;
        border-radius: 50% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        flex-shrink: 0 !important;
        margin-top: 2px !important;
      }

      #translation-box-container .user-icon {
        background: rgba(255, 255, 255, 0.2) !important;
      }

      #translation-box-container .ai-icon {
        background: linear-gradient(to right, #3b82f6, #7c3aed) !important;
      }

      #translation-box-container .error-icon {
        background: #ef4444 !important;
      }

      #translation-box-container .icon-svg {
        width: 12px !important;
        height: 12px !important;
        color: white !important;
        fill: white !important;
      }

      #translation-box-container .message-text-container {
        flex: 1 !important;
        min-width: 0 !important;
      }

      #translation-box-container .message-text {
        word-break: break-words !important;
        font-size: 12px !important;
        line-height: 1.5 !important;
        margin: 0 !important;
        white-space: pre-wrap !important;
      }

      #translation-box-container .error-text {
        font-weight: 500 !important;
      }

      /* Troubleshooting Section */
      #translation-box-container .troubleshooting-section {
        margin-top: 8px !important;
        padding: 8px !important;
        background: #fffbeb !important;
        border: 1px solid #fde68a !important;
        border-radius: 4px !important;
        font-size: 12px !important;
        color: #92400e !important;
      }

      #translation-box-container .troubleshooting-title {
        font-weight: 500 !important;
        margin: 0 0 4px 0 !important;
      }

      #translation-box-container .troubleshooting-list {
        list-style: disc !important;
        list-style-position: inside !important;
        margin: 0 !important;
        padding: 0 !important;
        display: flex !important;
        flex-direction: column !important;
        gap: 2px !important;
      }

      #translation-box-container .troubleshooting-list li {
        margin: 0 !important;
      }

      /* Copy Button */
      #translation-box-container .copy-button {
        position: absolute !important;
        bottom: 4px !important;
        right: 4px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        padding: 2px !important;
        border-radius: 3px !important;
        font-size: 0 !important;
        font-weight: 500 !important;
        transition: all 0.2s ease !important;
        opacity: 0 !important;
        cursor: pointer !important;
        border: none !important;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) !important;
        width: 16px !important;
        height: 16px !important;
        z-index: 10 !important;
      }

      #translation-box-container .message-bubble:hover .copy-button {
        opacity: 1 !important;
        transform: scale(1.1) !important;
      }

      #translation-box-container .user-copy {
        background: rgba(255, 255, 255, 0.9) !important;
        color: #2563eb !important;
        border: 1px solid rgba(255, 255, 255, 0.3) !important;
        font-weight: 600 !important;
      }

      #translation-box-container .user-copy:hover {
        background: rgba(255, 255, 255, 1) !important;
        transform: scale(1.1) !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.25) !important;
      }

      #translation-box-container .ai-copy {
        background: #3b82f6 !important;
        color: white !important;
        font-weight: 600 !important;
      }

      #translation-box-container .ai-copy:hover {
        background: #2563eb !important;
        transform: scale(1.1) !important;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.25) !important;
      }

      #translation-box-container .copy-icon {
        width: 10px !important;
        height: 10px !important;
        fill: currentColor !important;
        stroke: currentColor !important;
        stroke-width: 1.5 !important;
      }

      /* Loading States */
      #translation-box-container .loading-container {
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
        padding: 24px 0 !important;
        height: 100% !important;
      }

      #translation-box-container .loading-content {
        text-align: center !important;
      }

      #translation-box-container .loading-spinner {
        width: 24px !important;
        height: 24px !important;
        border: 4px solid #cbd5e1 !important;
        border-top: 4px solid #3b82f6 !important;
        border-radius: 50% !important;
        animation: spin 1s linear infinite !important;
        margin: 0 auto 12px !important;
      }

      #translation-box-container .loading-text {
        color: #475569 !important;
        font-size: 14px !important;
        font-weight: 500 !important;
        margin: 0 !important;
      }

      #translation-box-container .loading-message-bubble {
        background: #ffffff !important;
        border: 1px solid #e2e8f0 !important;
        border-radius: 12px !important;
        border-bottom-left-radius: 4px !important;
        padding: 12px !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .loading-message-content {
        display: flex !important;
        align-items: center !important;
        gap: 4px !important;
      }

      #translation-box-container .streaming-content {
        display: flex !important;
        gap: 4px !important;
      }

      #translation-box-container .streaming-text {
        font-size: 12px !important;
        color: #374151 !important;
        margin: 0 !important;
      }

      #translation-box-container .streaming-cursor {
        animation: blink 1s infinite !important;
        color: #3b82f6 !important;
        font-weight: bold !important;
      }

      #translation-box-container .loading-dots {
        display: flex !important;
        gap: 4px !important;
      }

      #translation-box-container .loading-dot {
        width: 6px !important;
        height: 6px !important;
        background: #9ca3af !important;
        border-radius: 50% !important;
        animation: bounce 1.4s infinite ease-in-out !important;
      }

      #translation-box-container .dot-1 {
        animation-delay: -0.32s !important;
      }

      #translation-box-container .dot-2 {
        animation-delay: -0.16s !important;
      }

      #translation-box-container .dot-3 {
        animation-delay: 0s !important;
      }

      #translation-box-container .loading-status {
        font-size: 12px !important;
        color: #6b7280 !important;
        margin-left: 8px !important;
      }

      /* Copy Alert */
      #translation-box-container .copy-alert {
        position: fixed !important;
        top: 80px !important;
        right: 16px !important;
        background: linear-gradient(to right, #10b981, #059669) !important;
        color: white !important;
        padding: 12px 16px !important;
        border-radius: 12px !important;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25) !important;
        z-index: 9999 !important;
        animation: fadeIn 0.3s ease-out !important;
        border: 1px solid #34d399 !important;
      }

      #translation-box-container .copy-alert-content {
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
      }

      #translation-box-container .copy-alert-icon {
        width: 20px !important;
        height: 20px !important;
        background: rgba(255, 255, 255, 0.2) !important;
        border-radius: 50% !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
      }

      #translation-box-container .check-icon {
        width: 12px !important;
        height: 12px !important;
        color: white !important;
        fill: white !important;
      }

      #translation-box-container .copy-alert-text {
        font-size: 14px !important;
        font-weight: 600 !important;
      }

      /* Animations */
      @keyframes spin {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(360deg);
        }
      }

      @keyframes bounce {
        0%, 80%, 100% {
          transform: scale(0);
        }
        40% {
          transform: scale(1);
        }
      }

      @keyframes blink {
        0%, 50% {
          opacity: 1;
        }
        51%, 100% {
          opacity: 0;
        }
      }

      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(-10px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      /* Update button removed - auto show update card */

      /* Update Card Styles */
      #translation-box-container .update-card-overlay {
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        z-index: 1000 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        background: rgba(0, 0, 0, 0.5) !important;
        backdrop-filter: blur(4px) !important;
      }

      #translation-box-container .update-card-backdrop {
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        cursor: pointer !important;
      }

      #translation-box-container .update-card-container {
        position: relative !important;
        background: #ffffff !important;
        border-radius: 16px !important;
        box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25) !important;
        border: 1px solid #e2e8f0 !important;
        width: 320px !important;
        max-width: 90% !important;
        overflow: hidden !important;
        animation: updateCardFadeIn 0.3s ease-out !important;
        display: flex !important;
        flex-direction: column !important;
        font-family: inherit !important;
        font-size: 14px !important;
        line-height: 1.5 !important;
      }

      #translation-box-container .update-card-header {
        background: linear-gradient(to right, #2563eb, #7c3aed, #4f46e5) !important;
        color: white !important;
        padding: 12px !important;
        flex-shrink: 0 !important;
        min-height: 48px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: space-between !important;
      }

      #translation-box-container .update-card-header-left {
        display: flex !important;
        align-items: center !important;
        gap: 8px !important;
      }

      #translation-box-container .update-card-flag-container {
        width: 24px !important;
        height: 24px !important;
        background: white !important;
        border-radius: 8px !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
        flex-shrink: 0 !important;
        overflow: hidden !important;
      }

      #translation-box-container .update-card-flag {
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
      }

      #translation-box-container .update-card-flag-icon {
        width: 16px !important;
        height: 16px !important;
        color: white !important;
      }

      #translation-box-container .update-card-header-text {
        display: flex !important;
        flex-direction: column !important;
        font-size: 18px !important;
      }

      #translation-box-container .update-card-title {
        font-weight: bold !important;
        font-size: 14px !important;
        margin: 0 !important;
        color: white !important;
      }

      #translation-box-container .update-card-subtitle {
        font-size: 12px !important;
        color: #bfdbfe !important;
        margin: 0 !important;
      }

      #translation-box-container .update-card-close-button {
        padding: 6px !important;
        background: none !important;
        border: none !important;
        color: white !important;
        border-radius: 8px !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        min-width: 24px !important;
        min-height: 24px !important;
        flex-shrink: 0 !important;
      }

      #translation-box-container .update-card-close-button:hover {
        background: rgba(255, 255, 255, 0.2) !important;
        transform: scale(1.05) !important;
      }

      #translation-box-container .update-card-close-icon {
        width: 16px !important;
        height: 16px !important;
        color: inherit !important;
      }

      #translation-box-container .update-card-body {
        padding: 16px !important;
        background: #f8fafc !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: center !important;
        align-items: center !important;
        text-align: center !important;
      }

      #translation-box-container .update-card-content-title {
        font-size: 20px !important;
        font-weight: 700 !important;
        color: #1e293b !important;
        margin-bottom: 12px !important;
        line-height: 1.4 !important;
      }

      #translation-box-container .update-card-content-description {
        font-size: 14px !important;
        color: #6b7280 !important;
        line-height: 1.6 !important;
        margin: 0 !important;
        max-width: 280px !important;
      }

      #translation-box-container .update-card-actions {
        display: flex !important;
        gap: 12px !important;
        padding: 16px !important;
        border-top: 1px solid #e2e8f0 !important;
        background: #ffffff !important;
        flex-shrink: 0 !important;
      }

      #translation-box-container .update-card-cancel-button {
        flex: 1 !important;
        padding: 10px 14px !important;
        background: #ffffff !important;
        border: 1px solid #d1d5db !important;
        color: #374151 !important;
        border-radius: 10px !important;
        font-size: 13px !important;
        font-weight: 500 !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        text-align: center !important;
        text-decoration: none !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        min-height: 40px !important;
      }

      #translation-box-container .update-card-cancel-button:hover {
        background: #f9fafb !important;
        border-color: #9ca3af !important;
        transform: scale(1.02) !important;
      }

      #translation-box-container .update-card-update-button {
        flex: 1 !important;
        padding: 10px 14px !important;
        background: linear-gradient(to right, #3b82f6, #1d4ed8) !important;
        border: 1px solid #3b82f6 !important;
        color: #ffffff !important;
        border-radius: 10px !important;
        font-size: 13px !important;
        font-weight: 500 !important;
        cursor: pointer !important;
        transition: all 0.2s ease !important;
        text-align: center !important;
        text-decoration: none !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        min-height: 40px !important;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
      }

      #translation-box-container .update-card-update-button:hover {
        background: linear-gradient(to right, #1d4ed8, #1e40af) !important;
        border-color: #1d4ed8 !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1) !important;
      }

      @keyframes updateCardFadeIn {
        from {
          opacity: 0;
          transform: scale(0.95) translateY(-10px);
        }
        to {
          opacity: 1;
          transform: scale(1) translateY(0);
        }
      }

      /* Custom Scrollbar */
      #translation-box-container .messages-container::-webkit-scrollbar {
        width: 8px !important;
      }

      #translation-box-container .messages-container::-webkit-scrollbar-track {
        background: rgba(241, 245, 249, 0.3) !important;
        border-radius: 10px !important;
        margin: 4px 0 !important;
      }

      #translation-box-container .messages-container::-webkit-scrollbar-thumb {
        background: linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%) !important;
        border-radius: 10px !important;
        border: 1px solid rgba(255, 255, 255, 0.8) !important;
        transition: all 0.3s ease !important;
      }

      #translation-box-container .messages-container::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(135deg, #cbd5e1 0%, #94a3b8 100%) !important;
        transform: scale(1.05) !important;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1) !important;
      }

      /* For Firefox */
      #translation-box-container .messages-container {
        scrollbar-width: thin !important;
        scrollbar-color: #cbd5e1 #f1f5f9 !important;
      }
    `,document.getElementById("translix-extension-styles")||document.head.appendChild(t),q=!0,console.log("Translix extension initialized successfully")}catch(t){console.error("Error initializing Translix extension:",t)}}function nt(){if(q)try{document.addEventListener("selectionchange",()=>{console.log("Selection change event triggered"),setTimeout(Q,100)}),document.addEventListener("mouseup",o=>{console.log("Mouse up event triggered");const{iconElementBN:e,iconElementEN:n}=K(),i=U();if(e&&e.contains(o.target)||n&&n.contains(o.target)||i&&i.contains(o.target)){console.log("Mouse up on icon or box, ignoring global handler");return}if(ht()){console.log("Ignoring global mouseup during long press processing");return}console.log("Calling handleSelectionEventWrapper from mouseup"),setTimeout(Q,150)}),document.addEventListener("keyup",o=>{(o.key==="Shift"||o.key.includes("Arrow"))&&setTimeout(Q,100)}),document.addEventListener("keydown",async o=>{if(o.ctrlKey&&console.log("Ctrl key pressed with:",o.key,"Current settings:",{PRIMARY_KEY:window.PRIMARY_KEY,SECONDARY_KEY:window.SECONDARY_KEY,PRIMARY_LANG:window.PRIMARY_LANG}),o.ctrlKey&&!o.altKey&&!o.shiftKey&&!o.metaKey){const e=o.key.toUpperCase();if(console.log("Checking key:",e,"against PRIMARY_KEY:",window.PRIMARY_KEY,"SECONDARY_KEY:",window.SECONDARY_KEY),e===window.PRIMARY_KEY){o.preventDefault(),console.log(`Ctrl+${window.PRIMARY_KEY} pressed for ${window.PRIMARY_LANG} translation`);const n=A();n&&n.text?await pt(window.PRIMARY_LANG):console.log(`No text selected, ignoring Ctrl+${window.PRIMARY_KEY}`)}else if(e===window.SECONDARY_KEY){o.preventDefault(),console.log(`Ctrl+${window.SECONDARY_KEY} pressed for EN translation`);const n=A();n&&n.text?await pt("EN"):console.log(`No text selected, ignoring Ctrl+${window.SECONDARY_KEY}`)}}}),document.addEventListener("scroll",()=>{const{iconElementBN:o,iconElementEN:e}=K(),n=A();if(o&&e&&n){const i=V();i?(o.style.top=`${i.top}px`,o.style.left=`${i.left}px`,e.style.top=`${i.top}px`,e.style.left=`${i.left+34}px`):(console.log("No valid position for icons on scroll, removing icons"),T(),C())}},{passive:!0});const t=At(()=>{const o=U();if(o){const e=D();e?(console.log(`Updating box position on resize: top=${e.top}, left=${e.left}, right=${e.right}, width=${e.width}, height=${e.height}`),o.style.top=`${e.top}px`,o.style.width=`${e.width}px`,o.style.height=`${e.height}px`,e.right!=="auto"?(o.style.right=`${e.right}px`,o.style.left="auto",o.style.transform="none"):e.left!=="auto"?(o.style.left=`${e.left}px`,o.style.right="auto",o.style.transform="none"):(o.style.left="50%",o.style.right="auto",o.style.transform="translateX(-50%)")):(console.log("No valid position for box on resize, removing box"),M())}},100);document.addEventListener("resize",()=>{console.log("Window resized, updating box size or removing icons and box"),U()&&t();const{iconElementBN:e,iconElementEN:n}=K(),i=A();if(e&&n&&i){const r=V();r?(e.style.top=`${r.top}px`,e.style.left=`${r.left}px`,n.style.top=`${r.top}px`,n.style.left=`${r.left+34}px`):(T(),C())}else T(),C()},{passive:!0}),window.addEventListener("beforeunload",()=>{console.log("Page unloading, removing icons and box"),T(),C(),M()}),chrome.storage.onChanged.addListener((o,e)=>{e==="sync"&&(o.primaryLang||o.primaryKey||o.secondaryKey)&&(console.log("Settings changed, reloading..."),wt().then(()=>{console.log("Settings reloaded:",window.PRIMARY_LANG,window.PRIMARY_KEY,window.SECONDARY_KEY)}))}),console.log("Translix event listeners added successfully")}catch(t){console.error("Error adding Translix event listeners:",t)}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",async()=>{await et(),nt()}):(async()=>(await et(),nt()))();window.addEventListener("load",async()=>{q||(await et(),nt())});window.AI_PROVIDER="openrouter";console.log("Translix content script loaded successfully");
